import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("nst_patcher", ROOT / "patch_apktool.py")
patcher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(patcher)


class InjectActivityTests(unittest.TestCase):
    def test_injects_after_super_call(self):
        source = (
            ".class public Lorg/cocos2dx/cpp/AppActivity;\n"
            ".super Lorg/cocos2dx/lib/Cocos2dxActivity;\n"
            ".method protected onCreate(Landroid/os/Bundle;)V\n"
            "    .locals 2\n"
            "    invoke-super {p0, p1}, Lorg/cocos2dx/lib/Cocos2dxActivity;->onCreate(Landroid/os/Bundle;)V\n"
            "    return-void\n"
            ".end method\n"
        )
        updated, changed = patcher.inject_activity(source)
        self.assertTrue(changed)
        self.assertIn(
            "invoke-static {p0}, Lcom/nst/mod/NstModBootstrap;->install(Landroid/app/Activity;)V",
            updated,
        )
        self.assertLess(updated.index("invoke-super"), updated.index("NstModBootstrap;->install"))

    def test_injection_is_idempotent(self):
        source = (
            ".method protected onCreate(Landroid/os/Bundle;)V\n"
            "    .locals 1\n"
            "    invoke-static {p0}, Lcom/nst/mod/NstModBootstrap;->install(Landroid/app/Activity;)V\n"
            "    return-void\n"
            ".end method\n"
        )
        updated, changed = patcher.inject_activity(source)
        self.assertFalse(changed)
        self.assertEqual(source, updated)

    def test_missing_method_fails_clearly(self):
        with self.assertRaisesRegex(RuntimeError, "onCreate"):
            patcher.inject_activity(".class public LExample;\n")


class PatchProjectTests(unittest.TestCase):
    def test_patch_adds_helper_assets_and_native_libraries(self):
        with tempfile.TemporaryDirectory() as temp:
            temp = Path(temp)
            project = temp / "decoded"
            kit = temp / "kit"
            libs = kit / "native" / "out"
            activity = project / "smali" / "org/cocos2dx/cpp/AppActivity.smali"
            activity.parent.mkdir(parents=True)
            activity.write_text(
                ".method protected onCreate(Landroid/os/Bundle;)V\n"
                "    .locals 1\n"
                "    invoke-super {p0, p1}, LBase;->onCreate(Landroid/os/Bundle;)V\n"
                "    return-void\n"
                ".end method\n",
                encoding="utf-8",
            )
            bootstrap = kit / "apktool" / "smali" / patcher.BOOTSTRAP_REL
            bootstrap.parent.mkdir(parents=True)
            bootstrap.write_text(".class public Lcom/nst/mod/NstModBootstrap;\n", encoding="utf-8")
            assets = kit / "assets" / "nst" / "Scripts"
            assets.mkdir(parents=True)
            (assets / "README_RU.txt").write_text("hello", encoding="utf-8")
            source_stale = kit / "assets" / "nst" / "Data" / "Mods"
            source_stale.mkdir(parents=True)
            (source_stale / "legacy.txt").write_text("legacy", encoding="utf-8")
            stale = project / "assets/nst/Data/Scripts"
            stale.mkdir(parents=True)
            (stale / "old.txt").write_text("old", encoding="utf-8")
            for abi in patcher.ABIS:
                path = libs / abi / "libnstmod.so"
                path.parent.mkdir(parents=True)
                path.write_bytes(b"fake native library for patcher test")

            patcher.patch(project, kit, libs, list(patcher.ABIS), False)
            self.assertIn("NstModBootstrap;->install", activity.read_text(encoding="utf-8"))
            self.assertTrue((project / "smali" / patcher.BOOTSTRAP_REL).is_file())
            self.assertTrue((project / "assets/nst/Scripts/README_RU.txt").is_file())
            self.assertFalse((project / "assets/nst/Data").exists())
            self.assertFalse((kit / "assets/nst/Data").exists())
            for abi in patcher.ABIS:
                self.assertTrue((project / "lib" / abi / "libnstmod.so").is_file())
            self.assertTrue((project / "NST_MODKIT_PATCH_REPORT.txt").is_file())


if __name__ == "__main__":
    unittest.main()
