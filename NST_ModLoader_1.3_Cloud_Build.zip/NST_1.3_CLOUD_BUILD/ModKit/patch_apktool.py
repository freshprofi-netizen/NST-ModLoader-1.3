#!/usr/bin/env python3
from __future__ import annotations
import argparse
import hashlib
import shutil
import sys
from pathlib import Path

ACTIVITY_REL = Path('org/cocos2dx/cpp/AppActivity.smali')
BOOTSTRAP_REL = Path('com/nst/mod/NstModBootstrap.smali')
INJECT = '    invoke-static {p0}, Lcom/nst/mod/NstModBootstrap;->install(Landroid/app/Activity;)V'
ABIS = ('arm64-v8a', 'armeabi-v7a')


def find_smali_roots(project: Path) -> list[Path]:
    return sorted(p for p in project.glob('smali*') if p.is_dir())


def find_activity(project: Path) -> tuple[Path, Path]:
    for root in find_smali_roots(project):
        candidate = root / ACTIVITY_REL
        if candidate.is_file():
            return root, candidate
    raise FileNotFoundError(
        'Не найден smali*/org/cocos2dx/cpp/AppActivity.smali. '
        'Проверь, что это декодированный APK именно Necromancer Story 2.0.14.'
    )


def inject_activity(source: str) -> tuple[str, bool]:
    if 'NstModBootstrap;->install(Landroid/app/Activity;)V' in source:
        return source, False
    lines = source.splitlines(keepends=True)
    start = None
    end = None
    for i, line in enumerate(lines):
        if line.strip().startswith('.method') and ' onCreate(Landroid/os/Bundle;)V' in line:
            start = i
            break
    if start is None:
        raise RuntimeError('В AppActivity.smali нет метода onCreate(Bundle).')
    for i in range(start + 1, len(lines)):
        if lines[i].strip() == '.end method':
            end = i
            break
    if end is None:
        raise RuntimeError('Не найден .end method для onCreate(Bundle).')

    invoke_index = None
    for i in range(start + 1, end):
        stripped = lines[i].strip()
        if stripped.startswith('invoke-super') and 'onCreate(Landroid/os/Bundle;)V' in stripped:
            invoke_index = i
            break
    if invoke_index is None:
        for i in range(start + 1, end):
            stripped = lines[i].strip()
            if stripped.startswith('.locals') or stripped.startswith('.registers'):
                invoke_index = i
                break
        if invoke_index is None:
            raise RuntimeError('Не удалось найти место для вставки в onCreate(Bundle).')
    lines.insert(invoke_index + 1, INJECT + '\n')
    return ''.join(lines), True


def copy_tree(source: Path, destination: Path) -> None:
    if not source.is_dir():
        raise FileNotFoundError(f'Не найдена папка с APK assets: {source}')
    destination.mkdir(parents=True, exist_ok=True)
    for item in source.iterdir():
        target = destination / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        else:
            shutil.copy2(item, target)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def patch(project: Path, kit: Path, libs_dir: Path, abis: list[str], check_only: bool) -> None:
    if not project.is_dir():
        raise FileNotFoundError(f'Папка декодированного APK не существует: {project}')
    smali_root, activity = find_activity(project)
    original = activity.read_text(encoding='utf-8')
    updated, changed = inject_activity(original)
    bootstrap_src = kit / 'apktool' / 'smali' / BOOTSTRAP_REL
    assets_src = kit / 'assets' / 'nst'
    if not bootstrap_src.is_file():
        raise FileNotFoundError(f'Не найден bootstrap-файл: {bootstrap_src}')
    if not assets_src.is_dir():
        raise FileNotFoundError(f'Не найдены assets мода: {assets_src}')
    native_files = {}
    for abi in abis:
        lib_src = libs_dir / abi / 'libnstmod.so'
        if not lib_src.is_file():
            raise FileNotFoundError(
                f'Нет {lib_src}. Сначала собери native/libnstmod.so для {abi} '
                'командой native\build_windows.bat или native/build_linux.sh.'
            )
        native_files[abi] = lib_src

    if check_only:
        print(f'OK: найден {activity.relative_to(project)}')
        print('OK: onCreate(Bundle) найден; вставка ' + ('нужна' if changed else 'уже есть'))
        print('OK: bootstrap и assets присутствуют в наборе')
        for abi, lib_src in native_files.items():
            print(f'OK: native {abi}: {lib_src.stat().st_size} bytes; SHA256 {sha256(lib_src)}')
        return

    if changed:
        activity.write_text(updated, encoding='utf-8', newline='')
    legacy_source_data = assets_src / 'Data'
    if legacy_source_data.exists():
        shutil.rmtree(legacy_source_data)
    bootstrap_dst = smali_root / BOOTSTRAP_REL
    bootstrap_dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(bootstrap_src, bootstrap_dst)

    assets_dst = project / 'assets' / 'nst'
    stale_data = assets_dst / 'Data'
    if stale_data.exists():
        shutil.rmtree(stale_data)
    copy_tree(assets_src, assets_dst)

    copied = []
    for abi, lib_src in native_files.items():
        lib_dst = project / 'lib' / abi / 'libnstmod.so'
        lib_dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(lib_src, lib_dst)
        copied.append((abi, sha256(lib_dst), lib_dst.stat().st_size))

    report = [
        'NST MODKIT 1.0 — PATCH REPORT',
        'Target: Necromancer Story 2.0.14',
        f'Activity: {activity.relative_to(project)}',
        'Bootstrap: injected after AppActivity.onCreate super call (or after register directive fallback)',
        'Assets: assets/nst/{Scripts,Mods,texture_pack} copied; stale assets/nst/Data removed',
        'Native hook library:',
    ]
    report.extend(f'  {abi}: {size} bytes; SHA256 {digest}' for abi, digest, size in copied)
    report += [
        '',
        'No APK was built or signed by this script.',
        'Rebuild with apktool, then align and sign the APK with your own signing key.',
        'First-run and in-game testing on a real device is still required.',
    ]
    (project / 'NST_MODKIT_PATCH_REPORT.txt').write_text('\n'.join(report) + '\n', encoding='utf-8')
    print('Патч внесён.')
    print(f'Activity: {activity}')
    print(f'Bootstrap: {bootstrap_dst}')
    print(f'Assets: {assets_dst}')
    for abi, _, size in copied:
        print(f'Native: {abi}/libnstmod.so ({size} bytes)')


def main() -> int:
    parser = argparse.ArgumentParser(description='Вставляет NST Mod Loader в декодированный Apktool-проект.')
    parser.add_argument('decoded_apk', type=Path, help='Папка после apktool d')
    parser.add_argument('--kit', type=Path, default=Path(__file__).resolve().parent, help='Папка ModKit')
    parser.add_argument('--libs-dir', type=Path, default=None, help='Папка native/out; по умолчанию <kit>/native/out')
    parser.add_argument('--abis', nargs='+', choices=ABIS, default=list(ABIS))
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    libs_dir = args.libs_dir or (args.kit / 'native' / 'out')
    try:
        patch(args.decoded_apk.resolve(), args.kit.resolve(), libs_dir.resolve(), args.abis, args.check_only)
    except Exception as exc:
        print(f'ОШИБКА: {exc}', file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
