.class public final Lcom/nst/mod/NstModBootstrap;
.super Ljava/lang/Object;

.method public static install(Landroid/app/Activity;)V
    .locals 2

    :try_start_0
    const-string v0, "nstmod"
    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    invoke-static {p0}, Lcom/nst/mod/NstModBootstrap;->nativeInstall(Landroid/app/Activity;)V
    :try_end_0
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v0
    const-string v1, "NSTMod"
    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/Throwable;)I
    return-void
.end method

.method private static native nativeInstall(Landroid/app/Activity;)V
.end method
