@echo off
cd /d %~dp0
if not exist .env (
  echo Create server\.env from server\.env.example and fill HiveMQ Cloud values.
  exit /b 2
)
if not exist .venv\Scripts\python.exe py -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m dotenv run -- python mqtt_server.py
