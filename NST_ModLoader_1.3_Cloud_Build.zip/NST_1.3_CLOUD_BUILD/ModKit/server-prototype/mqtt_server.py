from __future__ import annotations

import hmac
import json
import os
import ssl
import sys
import threading
import time
from collections import defaultdict, deque
from typing import Any

import paho.mqtt.client as mqtt

from game_core import GameError, GameServer

BROKER = os.environ.get("MQTT_HOST", "").strip()
PORT = int(os.environ.get("MQTT_PORT", "8883"))
USERNAME = os.environ.get("MQTT_USERNAME", "")
PASSWORD = os.environ.get("MQTT_PASSWORD", "")
ROOT = os.environ.get("MQTT_ROOT", "nst/v1").strip("/")
CLIENT_ID = os.environ.get("MQTT_CLIENT_ID", f"nst-game-{int(time.time())}")
KEEPALIVE = int(os.environ.get("MQTT_KEEPALIVE", "30"))

try:
    PLAYER_TOKENS: dict[str, str] = json.loads(os.environ.get("NST_PLAYER_TOKENS", "{}"))
except json.JSONDecodeError as exc:
    raise SystemExit(f"NST_PLAYER_TOKENS must be a JSON object: {exc}")

if not BROKER:
    raise SystemExit("Set MQTT_HOST to your HiveMQ Cloud cluster hostname. Do not use the public broker for a public release.")
if not USERNAME or not PASSWORD:
    raise SystemExit("Set MQTT_USERNAME and MQTT_PASSWORD from HiveMQ Cloud Access Management.")
if not isinstance(PLAYER_TOKENS, dict) or not PLAYER_TOKENS:
    raise SystemExit('Set NST_PLAYER_TOKENS, e.g. {"player-1":"long-random-token"}.')

core = GameServer()
core_lock = threading.RLock()
rate_lock = threading.Lock()
rate_history: dict[str, deque[float]] = defaultdict(deque)
RATE_LIMIT = int(os.environ.get("NST_COMMANDS_PER_SECOND", "15"))
MAX_PAYLOAD = 16 * 1024

client = mqtt.Client(
    mqtt.CallbackAPIVersion.VERSION2,
    client_id=CLIENT_ID,
    protocol=mqtt.MQTTv311,
)
client.username_pw_set(USERNAME, PASSWORD)
client.tls_set(cert_reqs=ssl.CERT_REQUIRED, tls_version=ssl.PROTOCOL_TLS_CLIENT)
client.reconnect_delay_set(min_delay=1, max_delay=30)


def publish_json(topic: str, value: dict[str, Any], qos: int = 1, retain: bool = False) -> None:
    payload = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    client.publish(topic, payload=payload, qos=qos, retain=retain)


def send_reply(player_id: str, data: dict[str, Any]) -> None:
    publish_json(f"{ROOT}/reply/{player_id}", data, qos=1)


def publish_room(room_id: str, snapshot: dict[str, Any], events: list[dict[str, Any]]) -> None:
    publish_json(f"{ROOT}/room/{room_id}/state", snapshot, qos=0, retain=True)
    for event in events:
        publish_json(f"{ROOT}/room/{room_id}/events", event, qos=1)


def authenticate(player_id: str, command: dict[str, Any]) -> None:
    expected = PLAYER_TOKENS.get(player_id)
    supplied = str(command.pop("token", ""))
    if not expected or not hmac.compare_digest(str(expected), supplied):
        raise GameError("Ошибка авторизации игрока")


def allow_rate(player_id: str) -> None:
    now = time.monotonic()
    with rate_lock:
        history = rate_history[player_id]
        while history and history[0] < now - 1.0:
            history.popleft()
        if len(history) >= RATE_LIMIT:
            raise GameError("Слишком много команд в секунду")
        history.append(now)


def dispatch(player_id: str, command: dict[str, Any]) -> None:
    if not isinstance(command, dict):
        send_reply(player_id, {"ok": False, "error": "Команда должна быть JSON-объектом"})
        return
    try:
        authenticate(player_id, command)
        allow_rate(player_id)
        kind = str(command.get("type", ""))
        before = len(core.events)
        with core_lock:
            if kind == "create":
                result = core.create_room(player_id, command.get("name", "Игрок"), command.get("mode", "coop"), bool(command.get("modified", False)))
                publish_room(result["room_id"], result["snapshot"], core.events[before:])
                send_reply(player_id, {"ok": True, "type": "created", **result})
                return

            if kind == "ring_queue":
                result = core.queue_ring(player_id, command.get("name", "Игрок"), bool(command.get("modified", False)))
                if result.get("status") == "matched":
                    room_id = result["room_id"]
                    publish_room(room_id, result["snapshot"], core.events[before:])
                    for matched_id in result["player_ids"]:
                        send_reply(matched_id, {"ok": True, "type": "ring_matched", **result})
                else:
                    send_reply(player_id, {"ok": True, **result})
                return

            if kind == "join" and command.get("room_code"):
                result = core.join_by_code(command["room_code"], player_id, command.get("name", "Игрок"), bool(command.get("modified", False)))
                room_id = result["room_id"]
                publish_room(room_id, result["snapshot"], core.events[before:])
                send_reply(player_id, {"ok": True, "type": "joined", **result})
                return

            room_id = str(command.get("room_id", ""))
            if kind != "join":
                room = core._room(room_id)
                if not hmac.compare_digest(room.secret, str(command.get("room_secret", ""))):
                    raise GameError("Неверный ключ комнаты")

            if kind == "join":
                result = core.join_room(room_id, str(command.get("room_secret", "")), player_id, command.get("name", "Игрок"), bool(command.get("modified", False)))
            elif kind == "leave":
                result = core.leave_room(room_id, player_id)
            elif kind == "move":
                result = core.update_state(room_id, player_id, command.get("x"), command.get("y"), command.get("weapon", "default"), command.get("outfit", "default"), command.get("armor", "default"))
            elif kind == "chat":
                result = core.chat(room_id, player_id, command.get("text", ""))
            elif kind == "equip":
                result = core.equip_item(room_id, player_id, command.get("item_id", ""), command.get("slot", ""))
            elif kind == "attack":
                result = core.attack_player(room_id, player_id, command.get("target_id", ""), command.get("damage", 1))
            elif kind == "inventory_add":
                result = core.add_inventory(room_id, player_id, command.get("item_id", ""))
            elif kind == "pickup_loot":
                result = core.pickup_loot(room_id, player_id, command.get("loot_id", ""))
            elif kind == "advance_level":
                result = core.advance_level(room_id, player_id)
            elif kind == "boss_attack":
                result = core.damage_boss(room_id, player_id, command.get("damage", 1))
            elif kind == "voice_signal":
                result = core.voice_signal(room_id, player_id, command.get("target_id", ""), command.get("signal", {}))
                target = str(command.get("target_id", ""))
                publish_json(f"{ROOT}/voice/{target}", result, qos=1)
                send_reply(player_id, {"ok": True, "type": "voice_signal_sent"})
                return
            else:
                raise GameError("Неизвестная команда")

            room = core.rooms.get(room_id)
            if room:
                publish_room(room_id, room.snapshot(), core.events[before:])
            elif kind == "leave":
                publish_json(f"{ROOT}/room/{room_id}/state", {"room_id": room_id, "closed": True}, qos=0, retain=True)
            send_reply(player_id, {"ok": True, "type": kind + "_result", "result": result})
    except (GameError, TypeError, ValueError, KeyError) as exc:
        send_reply(player_id, {"ok": False, "error": str(exc)[:180]})


def on_connect(mqtt_client, userdata, flags, reason_code, properties):
    if reason_code == 0:
        mqtt_client.subscribe(f"{ROOT}/cmd/+", qos=1)
        print(f"Connected to HiveMQ Cloud {BROKER}:{PORT}; subscribed {ROOT}/cmd/+")
    else:
        print(f"MQTT connection failed: {reason_code}", file=sys.stderr)


def on_message(mqtt_client, userdata, message):
    parts = message.topic.split("/")
    player_id = parts[-1] if parts else ""
    if not player_id or len(player_id) > 64 or player_id not in PLAYER_TOKENS:
        return
    if len(message.payload) > MAX_PAYLOAD:
        send_reply(player_id, {"ok": False, "error": "Команда слишком большая"})
        return
    try:
        command = json.loads(message.payload.decode("utf-8"))
        dispatch(player_id, command)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        send_reply(player_id, {"ok": False, "error": str(exc)[:180]})


client.on_connect = on_connect
client.on_message = on_message

if __name__ == "__main__":
    print("Necromancer Story multiplayer bridge — prototype")
    print("In-memory rooms are lost on restart; use a persistent backend before a public release.")
    client.connect(BROKER, PORT, keepalive=KEEPALIVE)
    client.loop_forever(retry_first_connection=True)
