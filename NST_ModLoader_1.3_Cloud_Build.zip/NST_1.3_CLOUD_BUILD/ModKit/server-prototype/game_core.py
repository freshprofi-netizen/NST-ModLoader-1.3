from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import math
import secrets
import time
from typing import Any


class GameError(Exception):
    pass


class Mode(str, Enum):
    ANARCHY = "anarchy"
    INFINITY = "infinity"
    RING = "ring"
    COOP = "coop"


@dataclass
class Player:
    player_id: str
    name: str
    hp: int = 100
    x: float = 0.0
    y: float = 0.0
    weapon: str = "default"
    outfit: str = "default"
    armor: str = "default"
    inventory: list[str] = field(default_factory=list)
    emeralds: int = 0
    coins: int = 0
    alive: bool = True
    modified_client: bool = False
    last_seen: float = field(default_factory=time.time)
    chat_bubble: dict[str, Any] | None = None

    def public_state(self) -> dict[str, Any]:
        return {
            "id": self.player_id,
            "name": self.name,
            "hp": self.hp,
            "alive": self.alive,
            "x": self.x,
            "y": self.y,
            "weapon": self.weapon,
            "outfit": self.outfit,
            "armor": self.armor,
            "inventory_count": len(self.inventory),
            "chat_bubble": self.chat_bubble,
        }


@dataclass
class Room:
    room_id: str
    secret: str
    room_code: str
    mode: Mode
    host_id: str
    players: dict[str, Player] = field(default_factory=dict)
    level: int = 1
    boss: dict[str, Any] | None = None
    shared_loot: list[str] = field(default_factory=list)
    dropped_loot: list[dict[str, Any]] = field(default_factory=list)
    state: str = "waiting"
    created_at: float = field(default_factory=time.time)
    match_winner: str | None = None

    def snapshot(self) -> dict[str, Any]:
        now = time.time()
        for player in self.players.values():
            if player.chat_bubble and player.chat_bubble.get("expires_at", 0) <= now:
                player.chat_bubble = None
        return {
            "room_id": self.room_id,
            "room_code": self.room_code,
            "mode": self.mode.value,
            "host_id": self.host_id,
            "state": self.state,
            "level": self.level,
            "boss": self.boss,
            "match_winner": self.match_winner,
            "shared_loot": list(self.shared_loot),
            "dropped_loot": list(self.dropped_loot),
            "players": [p.public_state() for p in self.players.values()],
        }


class GameServer:
    """Authoritative prototype for room rules. It is not connected to the game APK."""

    def __init__(self) -> None:
        self.rooms: dict[str, Room] = {}
        self.room_codes: dict[str, str] = {}
        self.ring_queue: list[tuple[str, str]] = []
        self.events: list[dict[str, Any]] = []

    @staticmethod
    def _safe_name(value: str) -> str:
        name = " ".join(str(value).strip().split())[:24]
        return name or "Игрок"

    @staticmethod
    def _safe_id(value: str) -> str:
        value = str(value).strip()
        if not value or len(value) > 64:
            raise GameError("Некорректный ID игрока")
        return value

    @staticmethod
    def _safe_asset_id(value: str) -> str:
        value = str(value).strip()
        if not value or len(value) > 48 or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-" for c in value):
            raise GameError("Некорректный ID предмета")
        return value

    def _event(self, room: Room, kind: str, **data: Any) -> dict[str, Any]:
        event = {"type": kind, "room_id": room.room_id, "at": time.time(), **data}
        self.events.append(event)
        if len(self.events) > 1000:
            del self.events[:500]
        return event

    def create_room(self, player_id: str, name: str, mode: str, modified_client: bool = False) -> dict[str, Any]:
        player_id = self._safe_id(player_id)
        if modified_client:
            raise GameError("Модификации отключены: выключите моды перед входом в мультиплеер")
        try:
            parsed_mode = Mode(mode)
        except ValueError as exc:
            raise GameError("Неизвестный режим") from exc
        if parsed_mode == Mode.RING:
            raise GameError("Для режима Ринг используйте подбор соперника")
        room_id = secrets.token_urlsafe(12)
        room_secret = secrets.token_urlsafe(18)
        words = ("ISKRA", "KEDR", "VOLK", "LUNA", "VETER", "NOVA", "TIGR", "RUNA", "BURYA", "ORBIT")
        room_code = None
        for _ in range(100):
            candidate = f"{secrets.choice(words)}-{secrets.randbelow(900) + 100}"
            if candidate not in self.room_codes:
                room_code = candidate
                break
        if room_code is None:
            room_code = secrets.token_urlsafe(5).upper()[:8]
        player = Player(player_id=player_id, name=self._safe_name(name))
        room = Room(room_id=room_id, secret=room_secret, room_code=room_code, mode=parsed_mode, host_id=player_id)
        room.players[player_id] = player
        room.state = "playing"
        self.rooms[room_id] = room
        self.room_codes[room_code] = room_id
        self._event(room, "player_joined", player=player.public_state())
        return {"room_id": room_id, "room_code": room_code, "room_secret": room_secret, "snapshot": room.snapshot()}

    def join_room(self, room_id: str, room_secret: str, player_id: str, name: str, modified_client: bool = False) -> dict[str, Any]:
        if modified_client:
            raise GameError("Модификации отключены: выключите моды перед входом в мультиплеер")
        room = self._room(room_id)
        if not secrets.compare_digest(room.secret, str(room_secret)):
            raise GameError("Неверный код комнаты")
        player_id = self._safe_id(player_id)
        if player_id in room.players:
            room.players[player_id].last_seen = time.time()
            return room.snapshot()
        if len(room.players) >= 4 and room.mode != Mode.RING:
            raise GameError("Комната заполнена")
        player = Player(player_id=player_id, name=self._safe_name(name))
        room.players[player_id] = player
        self._event(room, "player_joined", player=player.public_state())
        return room.snapshot()

    def join_by_code(self, room_code: str, player_id: str, name: str, modified_client: bool = False) -> dict[str, Any]:
        code = str(room_code).strip().upper()
        room_id = self.room_codes.get(code)
        if not room_id:
            raise GameError("Комната с таким словом не найдена")
        room = self._room(room_id)
        result = self.join_room(room_id, room.secret, player_id, name, modified_client)
        return {"room_id": room_id, "room_code": code, "room_secret": room.secret, "snapshot": result}

    def leave_room(self, room_id: str, player_id: str) -> dict[str, Any]:
        room = self._room(room_id)
        if player_id not in room.players:
            raise GameError("Игрок не найден в комнате")
        del room.players[player_id]
        self._event(room, "player_left", player_id=player_id)
        if not room.players:
            self.rooms.pop(room_id, None)
            self.room_codes.pop(room.room_code, None)
            return {"closed": True}
        if room.host_id == player_id:
            room.host_id = next(iter(room.players))
            self._event(room, "host_changed", host_id=room.host_id)
        return room.snapshot()

    def update_state(self, room_id: str, player_id: str, x: float, y: float, weapon: str, outfit: str, armor: str) -> dict[str, Any]:
        room = self._room(room_id)
        player = self._player(room, player_id)
        values = (float(x), float(y))
        if not all(math.isfinite(v) and abs(v) <= 100000 for v in values):
            raise GameError("Некорректные координаты")
        player.x, player.y = values
        player.weapon = self._safe_asset_id(weapon)
        player.outfit = self._safe_asset_id(outfit)
        player.armor = self._safe_asset_id(armor)
        player.last_seen = time.time()
        return room.snapshot()

    def chat(self, room_id: str, player_id: str, text: str) -> dict[str, Any]:
        room = self._room(room_id)
        player = self._player(room, player_id)
        message = " ".join(str(text).split())[:180]
        if not message:
            raise GameError("Пустое сообщение")
        player.chat_bubble = {"text": message, "expires_at": time.time() + 5.0}
        return self._event(room, "chat", player_id=player_id, player_name=player.name, text=message, bubble_seconds=5)

    def equip_item(self, room_id: str, player_id: str, item_id: str, slot: str) -> dict[str, Any]:
        room = self._room(room_id)
        player = self._player(room, player_id)
        item_id = self._safe_asset_id(item_id)
        if slot not in {"weapon", "outfit", "armor"}:
            raise GameError("Неизвестный слот")
        setattr(player, slot, item_id)
        player.last_seen = time.time()
        self._event(room, "equipment_changed", player_id=player_id, slot=slot, item_id=item_id)
        return room.snapshot()

    def attack_player(self, room_id: str, attacker_id: str, target_id: str, damage: int) -> dict[str, Any]:
        room = self._room(room_id)
        if room.mode == Mode.INFINITY or room.mode == Mode.COOP:
            raise GameError("В этом режиме PvP отключено")
        if attacker_id == target_id:
            raise GameError("Нельзя атаковать себя")
        attacker = self._player(room, attacker_id)
        target = self._player(room, target_id)
        if not attacker.alive or not target.alive:
            raise GameError("Мёртвый игрок не может участвовать в бою")
        if room.mode == Mode.RING and (len(room.players) != 2 or room.state != "playing"):
            raise GameError("Матч Ринг не готов")
        damage = max(1, min(int(damage), 100))
        target.hp = max(0, target.hp - damage)
        self._event(room, "player_damaged", attacker_id=attacker_id, target_id=target_id, damage=damage, hp=target.hp)
        if target.hp == 0:
            target.alive = False
            if room.mode == Mode.ANARCHY:
                dropped = list(target.inventory)
                if target.weapon != "default":
                    dropped.append(target.weapon)
                if target.outfit != "default":
                    dropped.append(target.outfit)
                if target.armor != "default":
                    dropped.append(target.armor)
                target.inventory.clear()
                target.weapon = target.outfit = target.armor = "default"
                loot_entries = []
                for item_id in dropped:
                    entry = {"loot_id": secrets.token_urlsafe(8), "item_id": item_id, "owner_id": target_id}
                    room.dropped_loot.append(entry)
                    loot_entries.append(entry)
                self._event(room, "loot_dropped", player_id=target_id, items=loot_entries)
            elif room.mode == Mode.RING:
                room.match_winner = attacker_id
                room.state = "finished"
                attacker.emeralds += 10
                attacker.coins += 500
                self._event(room, "ring_finished", winner_id=attacker_id, loser_id=target_id, reward={"emeralds": 10, "coins": 500})
        return room.snapshot()

    def add_inventory(self, room_id: str, player_id: str, item_id: str) -> dict[str, Any]:
        room = self._room(room_id)
        player = self._player(room, player_id)
        safe_item = self._safe_asset_id(item_id)
        if room.mode in {Mode.COOP, Mode.INFINITY}:
            room.shared_loot.append(safe_item)
            for member in room.players.values():
                if member.alive:
                    member.inventory.append(safe_item)
            self._event(room, "shared_loot_added", item_id=safe_item)
        else:
            player.inventory.append(safe_item)
        return room.snapshot()

    def pickup_loot(self, room_id: str, player_id: str, loot_id: str) -> dict[str, Any]:
        room = self._room(room_id)
        player = self._player(room, player_id)
        if not player.alive:
            raise GameError("Мёртвый игрок не может подбирать лут")
        for index, entry in enumerate(room.dropped_loot):
            if entry["loot_id"] == loot_id:
                item_id = entry["item_id"]
                player.inventory.append(item_id)
                room.dropped_loot.pop(index)
                self._event(room, "loot_picked_up", player_id=player_id, item_id=item_id)
                return room.snapshot()
        raise GameError("Предмет уже подобран или не существует")

    def advance_level(self, room_id: str, player_id: str) -> dict[str, Any]:
        room = self._room(room_id)
        self._player(room, player_id)
        if room.mode == Mode.COOP and player_id != room.host_id:
            raise GameError("В обычной комнате уровень может завершить только хост")
        if room.mode not in {Mode.INFINITY, Mode.COOP}:
            raise GameError("Переход уровня здесь недоступен")
        if room.boss is not None and room.boss.get("hp", 0) > 0:
            raise GameError("Сначала победите босса")
        room.level += 1
        if room.mode == Mode.INFINITY and room.level % 5 == 0:
            room.boss = {"id": f"boss_{room.level}", "name": "Страж бесконечности", "hp": 1200 + room.level * 100, "max_hp": 1200 + room.level * 100}
            self._event(room, "boss_spawned", boss=room.boss)
        else:
            room.boss = None
        self._event(room, "level_advanced", level=room.level)
        return room.snapshot()

    def damage_boss(self, room_id: str, player_id: str, damage: int) -> dict[str, Any]:
        room = self._room(room_id)
        player = self._player(room, player_id)
        if room.mode != Mode.INFINITY or room.boss is None:
            raise GameError("Сейчас босса нет")
        if not player.alive:
            raise GameError("Мёртвый игрок не может атаковать")
        amount = max(1, min(int(damage), 100))
        room.boss["hp"] = max(0, room.boss["hp"] - amount)
        if room.boss["hp"] == 0:
            loot = [f"boss_relic_{room.level}", f"boss_weapon_{room.level}"]
            room.shared_loot.extend(loot)
            for member in room.players.values():
                if member.alive:
                    member.inventory.extend(loot)
            self._event(room, "boss_defeated", loot=loot)
        else:
            self._event(room, "boss_damaged", player_id=player_id, damage=amount, hp=room.boss["hp"])
        return room.snapshot()

    def queue_ring(self, player_id: str, name: str, modified_client: bool = False) -> dict[str, Any]:
        if modified_client:
            raise GameError("Модификации отключены: выключите моды перед входом в мультиплеер")
        player_id = self._safe_id(player_id)
        if any(existing_id == player_id for existing_id, _ in self.ring_queue):
            raise GameError("Вы уже ожидаете соперника")
        self.ring_queue.append((player_id, self._safe_name(name)))
        if len(self.ring_queue) < 2:
            return {"status": "searching"}
        first_id, first_name = self.ring_queue.pop(0)
        second_id, second_name = self.ring_queue.pop(0)
        created = self.create_room(first_id, first_name, Mode.ANARCHY.value)
        room = self._room(created["room_id"])
        room.mode = Mode.RING
        self.join_room(room.room_id, room.secret, second_id, second_name)
        room.state = "playing"
        self._event(room, "ring_started", players=[first_id, second_id])
        return {"status": "matched", "room_id": room.room_id, "room_code": room.room_code, "room_secret": room.secret, "player_ids": [first_id, second_id], "snapshot": room.snapshot()}

    def voice_signal(self, room_id: str, sender_id: str, target_id: str, signal: dict[str, Any]) -> dict[str, Any]:
        room = self._room(room_id)
        self._player(room, sender_id)
        self._player(room, target_id)
        if sender_id == target_id:
            raise GameError("Нельзя отправить сигнал самому себе")
        kind = str(signal.get("type", ""))
        if kind not in {"offer", "answer", "candidate", "hangup"}:
            raise GameError("Недопустимый WebRTC-сигнал")
        serialized_size = len(str(signal).encode("utf-8"))
        if serialized_size > 12000:
            raise GameError("Слишком большой WebRTC-сигнал")
        return self._event(room, "voice_signal", sender_id=sender_id, target_id=target_id, signal=signal)

    def _room(self, room_id: str) -> Room:
        try:
            return self.rooms[room_id]
        except KeyError as exc:
            raise GameError("Комната не найдена") from exc

    @staticmethod
    def _player(room: Room, player_id: str) -> Player:
        try:
            player = room.players[player_id]
        except KeyError as exc:
            raise GameError("Игрок не найден в комнате") from exc
        player.last_seen = time.time()
        return player
