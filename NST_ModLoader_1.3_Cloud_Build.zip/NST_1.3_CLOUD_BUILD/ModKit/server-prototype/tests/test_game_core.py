import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "server"))
from game_core import GameError, GameServer, Mode


class GameCoreTests(unittest.TestCase):
    def setUp(self):
        self.server = GameServer()

    def room_with_two(self, mode):
        result = self.server.create_room("p1", "Первый", mode)
        self.server.join_room(result["room_id"], result["room_secret"], "p2", "Второй")
        return result["room_id"], result["room_secret"]

    def test_anarchy_drops_inventory_and_equipment_on_death(self):
        room_id, _ = self.room_with_two(Mode.ANARCHY.value)
        self.server.add_inventory(room_id, "p2", "rare_amulet")
        self.server.equip_item(room_id, "p2", "iron_sword", "weapon")
        state = self.server.attack_player(room_id, "p1", "p2", 100)
        second = next(p for p in state["players"] if p["id"] == "p2")
        self.assertFalse(second["alive"])
        self.assertEqual(second["inventory_count"], 0)
        loot_event = next(e for e in self.server.events if e["type"] == "loot_dropped")
        iron_sword = next(item for item in loot_event["items"] if item["item_id"] == "iron_sword")
        self.assertEqual(state["dropped_loot"], loot_event["items"])
        picked = self.server.pickup_loot(room_id, "p1", iron_sword["loot_id"])
        first = next(p for p in picked["players"] if p["id"] == "p1")
        self.assertEqual(first["inventory_count"], 1)

    def test_infinity_has_shared_boss_and_rewards(self):
        created = self.server.create_room("p1", "Первый", Mode.INFINITY.value)
        room_id = created["room_id"]
        self.server.join_room(room_id, created["room_secret"], "p2", "Второй")
        for _ in range(4):
            self.server.advance_level(room_id, "p1")
        state = self.server._room(room_id).snapshot()
        self.assertEqual(state["level"], 5)
        self.assertIsNotNone(state["boss"])
        for index in range(17):
            state = self.server.damage_boss(room_id, "p1" if index % 2 == 0 else "p2", 100)
        self.assertEqual(state["boss"]["hp"], 0)
        self.assertTrue(any("boss_relic_5" in p.inventory for p in self.server._room(room_id).players.values()))

    def test_ring_match_and_reward(self):
        first = self.server.queue_ring("p1", "Первый")
        self.assertEqual(first["status"], "searching")
        match = self.server.queue_ring("p2", "Второй")
        self.assertEqual(match["status"], "matched")
        state = self.server.attack_player(match["room_id"], "p1", "p2", 100)
        self.assertEqual(state["match_winner"], "p1")
        winner = next(p for p in self.server._room(match["room_id"]).players.values() if p.player_id == "p1")
        self.assertEqual(winner.emeralds, 10)
        self.assertEqual(winner.coins, 500)

    def test_modded_client_is_rejected(self):
        with self.assertRaises(GameError):
            self.server.create_room("p1", "Первый", Mode.ANARCHY.value, modified_client=True)

    def test_coop_progression_only_host(self):
        created = self.server.create_room("p1", "Хост", Mode.COOP.value)
        self.server.join_room(created["room_id"], created["room_secret"], "p2", "Друг")
        with self.assertRaises(GameError):
            self.server.advance_level(created["room_id"], "p2")
        self.assertEqual(self.server.advance_level(created["room_id"], "p1")["level"], 2)

    def test_infinity_disables_pvp(self):
        room_id, _ = self.room_with_two(Mode.INFINITY.value)
        with self.assertRaises(GameError):
            self.server.attack_player(room_id, "p1", "p2", 10)

    def test_join_by_random_word_code(self):
        created = self.server.create_room("p1", "Хост", Mode.COOP.value)
        joined = self.server.join_by_code(created["room_code"], "p2", "Друг")
        self.assertEqual(joined["room_id"], created["room_id"])
        self.assertEqual(joined["room_secret"], created["room_secret"])
        self.assertEqual(len(joined["snapshot"]["players"]), 2)

    def test_coop_loot_is_shared_to_all_players(self):
        created = self.server.create_room("p1", "Хост", Mode.COOP.value)
        room_id = created["room_id"]
        self.server.join_room(room_id, created["room_secret"], "p2", "Друг")
        state = self.server.add_inventory(room_id, "p1", "shared_sword")
        for player in state["players"]:
            self.assertEqual(player["inventory_count"], 1)
        self.assertEqual(state["shared_loot"], ["shared_sword"])

    def test_voice_signal_is_limited_to_webrtc_signal_types(self):
        room_id, _ = self.room_with_two(Mode.COOP.value)
        event = self.server.voice_signal(room_id, "p1", "p2", {"type": "offer", "sdp": "test"})
        self.assertEqual(event["type"], "voice_signal")
        with self.assertRaises(GameError):
            self.server.voice_signal(room_id, "p1", "p2", {"type": "shell", "data": "no"})


if __name__ == "__main__":
    unittest.main(verbosity=2)
