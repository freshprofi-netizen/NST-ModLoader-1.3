# Multiplayer transport protocol v1

Transport: MQTT over TLS (HiveMQ Cloud), JSON UTF-8 payloads.
Root topic: `nst/v1`.

- Client commands: `nst/v1/cmd/{player_id}` — QoS 1 for commands, QoS 0 for frequent movement.
- Private response: `nst/v1/reply/{player_id}` — QoS 1.
- Room state: `nst/v1/room/{room_id}/state` — retained snapshot, QoS 0.
- Room events: `nst/v1/room/{room_id}/events` — QoS 1.
- WebRTC signalling: `nst/v1/voice/{target_player_id}` — QoS 1.

Every command includes `token`. The server checks it against the `NST_PLAYER_TOKENS`
map on the server. Do not embed broker admin credentials in the APK. Each player
must receive a distinct player token from an account/authentication backend.

## Commands

Create room:
```json
{"type":"create","name":"Player","mode":"coop","modified":false,"token":"PLAYER_TOKEN"}
```
The reply contains `room_code` (a short word plus three digits), `room_id`, `room_secret`, and the
initial snapshot. Share the word with a friend. Join with:
```json
{"type":"join","room_code":"KEDR-482","name":"Friend","modified":false,"token":"PLAYER_TOKEN"}
```
After joining, the reply also contains `room_secret`. Subsequent room commands
include `room_id` and `room_secret`.

Movement/equipment:
```json
{"type":"move","room_id":"...","room_secret":"...","x":12.5,"y":4.2,"weapon":"iron_sword","outfit":"knight_01","armor":"steel","token":"..."}
```

Chat:
```json
{"type":"chat","room_id":"...","room_secret":"...","text":"Hello!","token":"..."}
```
The room event includes the player ID/name and `bubble_seconds`; the game client
must render it above that player's world-space position.

Other command types: `attack`, `equip`, `inventory_add`, `pickup_loot`,
`advance_level`, `boss_attack`, `voice_signal`, `leave`, `ring_queue`.
See `server/game_core.py` for the prototype rules.

## Modes

- `anarchy`: PvP on. On death inventory and equipped weapon/outfit/armor are dropped.
- `infinity`: PvP off. Shared level, shared loot, boss every five levels.
- `ring`: queue for one opponent. Winner receives 10 emeralds and 500 coins.
- `coop`: invite by short word; shared loot; only host advances the level.

The Python server's rooms are in memory and disappear after a restart. Combat
validation is a prototype: the game client must send authoritative combat events
only after local game events, and a production server needs anti-cheat validation,
persistence, matchmaking cleanup, and account-backed identity.

## Important limitations

The C++ `MultiplayerGameAdapter` is an integration interface. The original APK
has no multiplayer entity hooks. The network prototype cannot create real remote
Cocos characters until the adapter is implemented with the game's Character and
rendering systems. The `modified` flag is client-supplied and is NOT a secure
anti-cheat attestation; a production release needs signed-client verification.
