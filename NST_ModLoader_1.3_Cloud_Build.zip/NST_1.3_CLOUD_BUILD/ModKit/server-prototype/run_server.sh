#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if [ ! -f .env ]; then
  echo "Create server/.env from server/.env.example and fill in HiveMQ Cloud values."
  exit 2
fi
python3 -m venv .venv 2>/dev/null || true
. .venv/bin/activate
python -m pip install -r requirements.txt
exec python -m dotenv run -- python mqtt_server.py
