# Voice chat — implementation contract

The MQTT bridge relays WebRTC signalling messages (`offer`, `answer`, `candidate`,
`hangup`) between room members. It does not carry microphone audio. Actual voice
requires an Android WebRTC SDK, microphone permission, peer-connection lifecycle,
STUN and a TURN server for networks where direct P2P fails.

Push-to-talk UI state:
- pointer down: request microphone permission if needed, unmute local audio, tint mic green;
- pointer up/cancel/focus loss: mute immediately, restore gray icon;
- room leave/disconnect: close peer connection and release audio resources;
- background/app pause: force mute and stop capture unless a foreground service is explicitly implemented.

The server only validates and forwards signalling messages. TURN credentials must
be short-lived and issued by a backend; never hardcode a permanent TURN secret in
an APK. `server/docker-compose.turn.yml` is a self-hosted coturn starting point.

Voice UI, audio transport and Cocos microphone overlay are not integrated in the
provided original APK. Do not describe signalling-only as a working voice chat.
