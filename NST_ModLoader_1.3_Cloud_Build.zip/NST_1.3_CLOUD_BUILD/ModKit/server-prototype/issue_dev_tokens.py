import json
import secrets
import sys

ids = [value.strip() for value in sys.argv[1:] if value.strip()]
if not ids:
    ids = ["player-1", "player-2"]
if len(ids) != len(set(ids)):
    raise SystemExit("Player IDs must be unique")
print(json.dumps({player_id: secrets.token_urlsafe(32) for player_id in ids}, ensure_ascii=False))
