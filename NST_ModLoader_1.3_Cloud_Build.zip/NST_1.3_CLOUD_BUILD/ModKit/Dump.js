'use strict';

globalThis.NST_DUMP = Object.freeze({
    target: {
        package: 'com.achrogames.necromancerstory',
        gameVersion: '2.0.14',
        engine: 'Cocos2d-x',
        nativeLibrary: 'libMyGame.so',
        abis: ['arm64-v8a', 'armeabi-v7a']
    },
    runtime: {
        javascript: 'QuickJS-NG 0.17.0',
        hookLibrary: 'Dobby 5dfc854',
        entryPoint: 'org.cocos2dx.cpp.AppActivity.onCreate(Bundle)',
        gameHooks: ['GameScene::init()', 'GameScene::FrameMove(float)']
    },
    verifiedArm64Rva: {
        'Character::SetTarget(Character*)': 0x00350de0,
        'Character::MoveToTarget()': 0x00350e00,
        'Character::AttackAble(Character*)': 0x0035096c,
        'Character::Attack(bool)': 0x0034b2cc,
        'Character::SetEnemy(bool)': 0x00349cf8,
        'Character::SetVisible(bool)': 0x0034ad98,
        'Character::Equip(EquipmentType,int,Color)': 0x0034eed0,
        'Stage::CreateMob(CharacterType,int,int,int,int)': 0x003df92c,
        'Stage::AddMob(Character*)': 0x003df9e8,
        'Stage::RemoveMob(Character*)': 0x003dfa84,
        'Stage::PickUpItem()': 0x003dddcc,
        'Stage::AutoPickupProc()': 0x003ddf50,
        'GameScene::init()': 0x0035dcb0,
        'GameScene::FrameMove(float)': 0x0035f1cc,
        'GameScene::CreateScene()': 0x0035d870,
        'User::Ins(UserType)': 0x003355c4,
        'UserData::GetGameLevel()': 0x003e83cc,
        'cocos2d::Node::getPosition() const': 0x0047d3e8,
        'cocos2d::FileUtils::getInstance()': 0x003ebde8
    },
    verifiedArm64ObjectLayout: {
        'Character::CharacterType': 0x4274,
        'Stage::characters.begin': 0x358,
        'Stage::characters.end': 0x360,
        'Stage::characters.capacity': 0x368,
        'StageMgr::staticSingleton.firstMember': 0x0
    },
    exportedSymbolsUsedByName: [
        '_ZN9GameScene4initEv',
        '_ZN9GameScene9FrameMoveEf',
        '_ZN4User3InsE8UserType',
        '_ZN8UserData12GetGameLevelEv',
        '_ZN5Stage9CreateMobE13CharacterTypeiiii',
        '_ZN5Stage9RemoveMobEP9Character',
        '_ZN9Character9SetTargetEPS_',
        '_ZN9Character8SetEnemyEb',
        '_ZN9Character12MoveToTargetEv',
        '_ZN9Character10AttackAbleEPS_',
        '_ZN9Character6AttackEb',
        '_ZNK7cocos2d4Node11getPositionEv',
        '_ZN7cocos2d9FileUtils11getInstanceEv',
        '_ZN7cocos2d9FileUtils13addSearchPathERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEb'
    ],
    javascriptApi: {
        Mod: ['register({id,name,version})'],
        UI: ['addButton(id,label,callback)', 'notify(text)'],
        Events: ['on("tick", callback)', 'off("tick")'],
        Logger: ['info(text)', 'error(text)'],
        Player: ['getPosition() -> {x,y}'],
        World: ['spawnClone(options) -> id', 'despawnClone()', 'setCloneAI(id,settings)', 'getCloneState()']
    },
    limitations: [
        'The clone native adapter is enabled only for arm64-v8a; armv7 has no validated Character/Stage structure offsets in this kit.',
        'Clone uses player CharacterType and current game level. Equipment/cosmetic copy is not reverse-engineered.',
        'Clone loot pickup and automatic equipment upgrades are not implemented.',
        'Multiplayer room server prototype is separate and has no in-game MQTT client adapter.',
        'WebRTC audio, push-to-talk, remote Character rendering and anti-cheat attestation are not implemented.'
    ]
});
