Текстур-паки
============

Активный каталог: NSTMods/texture_pack/Active/
Резервный каталог: NSTMods/texture_pack/Original/

Структура активного пака сохраняет пути оригинальных ресурсов, например
Active/assets/img/img.png и Active/assets/img/img.plist. Не удаляй Original.
