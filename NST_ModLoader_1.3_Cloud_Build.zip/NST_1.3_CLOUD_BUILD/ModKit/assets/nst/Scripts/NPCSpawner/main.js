'use strict';

Mod.register({
    id: 'npc_spawner',
    name: 'Создание NPC',
    version: '1.0.0'
});

function currentSelection() {
    return World.getNpcSelection();
}

UI.addButton('npc_next_type', 'Следующий тип NPC', function () {
    const selection = currentSelection();
    const types = World.getNpcTypes();
    selection.type = (selection.type + 1) % types.length;
    World.setNpcSelection(selection);
    UI.notify('Выбран NPC: ' + types[selection.type].name);
});

UI.addButton('npc_toggle_side', 'Друг / противник', function () {
    const selection = currentSelection();
    selection.enemy = !selection.enemy;
    World.setNpcSelection(selection);
    UI.notify(selection.enemy ? 'Сторона: противник' : 'Сторона: друг');
});

UI.addButton('npc_spawn_selected', 'Призвать выбранного NPC', function () {
    try {
        const selection = currentSelection();
        const id = World.spawnNpc(selection);
        UI.notify('NPC создан: ' + id);
        Logger.info('Создан NPC ' + id + ', тип ' + selection.type + ', enemy=' + selection.enemy);
    } catch (error) {
        UI.notify('Не удалось создать NPC: ' + error.message);
        Logger.error(error.message);
    }
});

Logger.info('Мод создания NPC загружен.');
