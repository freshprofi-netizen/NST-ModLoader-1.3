# NST Mod Loader API 1.0

## Формат папки

```text
NSTMods/
  Scripts/
    MyMod/
      mod.json
      main.js
  Mods/
    MyLargeMod/
      main.js
  texture_pack/
    Active/assets/img/...
    Original/assets/img/...
```

## JS API

| Объект | Функция | Реализация в этом комплекте |
|---|---|---|
| `Mod` | `register({id,name,version})` | Да |
| `UI` | `addButton(id,label,callback)` | Да |
| `UI` | `notify(text)` | Пишет в logcat |
| `Events` | `on('tick', callback)` | Да, callback получает `dt` |
| `Events` | `off('tick')` | Да |
| `Logger` | `info(text)`, `error(text)` | Да |
| `Player` | `getPosition()` | Возвращает `{x,y}` |
| `World` | `spawnClone(options)` | Базовое создание на ARM64 |
| `World` | `despawnClone()` | Да, пока Stage активен |
| `World` | `setCloneAI(id, settings)` | Следование и атака поддержаны частично |
| `World` | `getCloneState()` | Да |

## Runtime

- QuickJS-NG 0.17.0;
- ограничения памяти JS: 8 MiB;
- максимальный стек JS: 512 KiB;
- лимит одного запуска скрипта: около 100 ms;
- лимит callback: около 30 ms; лимит tick callback около 3 ms;
- нет встроенных Node.js API, `require`, `fs` или MQTT из JS.

## Нативные игровые точки

Хуки выполняются в `GameScene::init()` и `GameScene::FrameMove(float)`.
Имена игровых символов разрешаются через `dlsym` по экспортированным C++ именам,
а не через зашитые RVA. Это убирает зависимость от смещения функции в пределах
сборки, но не гарантирует совместимость с другими версиями игры.

ARM64-only layout:

- `Character::CharacterType`: `Character* + 0x4274`;
- `Stage` mob vector begin/end/capacity: `+0x358`, `+0x360`, `+0x368`;
- `StageMgr::Ins()` static object: первый член по `+0` содержит указатель на Stage.

На ARMv7 структура Stage/Character не проверена, поэтому создание клона выключено.
