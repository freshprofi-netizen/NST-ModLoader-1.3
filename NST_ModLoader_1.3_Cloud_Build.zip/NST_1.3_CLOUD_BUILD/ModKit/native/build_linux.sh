#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to Android NDK r26 or newer}"
for ABI in arm64-v8a armeabi-v7a; do
  BUILD="$ROOT/build/$ABI"
  cmake -S "$ROOT" -B "$BUILD" -G Ninja \
    -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="$ABI" -DANDROID_PLATFORM=android-21 \
    -DANDROID_STL=c++_static -DCMAKE_BUILD_TYPE=Release
  cmake --build "$BUILD" --target nstmod
  mkdir -p "$ROOT/out/$ABI"
  cp "$BUILD/libnstmod.so" "$ROOT/out/$ABI/libnstmod.so"
done
printf 'Native libraries ready in %s/out\n' "$ROOT"
