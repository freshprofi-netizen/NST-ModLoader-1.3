@echo off
setlocal
if "%ANDROID_NDK_HOME%"=="" (
  echo Set ANDROID_NDK_HOME to Android NDK r26 or newer.
  exit /b 1
)
set ROOT=%~dp0
set OUT=%ROOT%out
if not exist "%OUT%" mkdir "%OUT%"

call :build arm64-v8a
if errorlevel 1 exit /b 1
call :build armeabi-v7a
if errorlevel 1 exit /b 1

echo Native libraries are ready in native\out\.
exit /b 0

:build
set ABI=%~1
set BUILD=%ROOT%build\%ABI%
cmake -S "%ROOT%" -B "%BUILD%" -G Ninja -DCMAKE_TOOLCHAIN_FILE="%ANDROID_NDK_HOME%\build\cmake\android.toolchain.cmake" -DANDROID_ABI=%ABI% -DANDROID_PLATFORM=android-21 -DANDROID_STL=c++_static -DCMAKE_BUILD_TYPE=Release
if errorlevel 1 exit /b 1
cmake --build "%BUILD%" --target nstmod
if errorlevel 1 exit /b 1
if not exist "%OUT%\%ABI%" mkdir "%OUT%\%ABI%"
copy /Y "%BUILD%\libnstmod.so" "%OUT%\%ABI%\libnstmod.so" >nul
if errorlevel 1 exit /b 1
exit /b 0
