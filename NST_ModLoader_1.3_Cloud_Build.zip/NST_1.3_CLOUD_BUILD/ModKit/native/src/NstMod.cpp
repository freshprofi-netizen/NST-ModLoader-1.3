#include <jni.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <dirent.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <dobby.h>
#include <quickjs.h>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <string>
#include <utility>
#include <vector>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "NSTMod", __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, "NSTMod", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "NSTMod", __VA_ARGS__)

namespace cocos2d {
struct Vec2 { float x; float y; };
struct Size { float width; float height; };
struct Color4B { unsigned char r, g, b, a; };
class Ref;
class Node;
class Label;
class MenuItem;
class Menu;
class LayerColor;
class Director;
}

namespace {
constexpr const char* kTag = "NSTMod";
constexpr uintptr_t kArm64CharacterTypeOffset = 0x4274;
constexpr uintptr_t kArm64StageMobsBeginOffset = 0x358;
constexpr uintptr_t kArm64StageMobsEndOffset = 0x360;
constexpr size_t kMaxCharacters = 160;

std::string g_basePath;
void* g_gameHandle = nullptr;
void* g_currentScene = nullptr;
void* g_menuButton = nullptr;
void* g_menuPanel = nullptr;
void* g_menuBackdrop = nullptr;
void* g_clone = nullptr;
void* g_cloneStage = nullptr;
void* g_player = nullptr;
std::atomic<bool> g_initialized{false};
std::atomic<bool> g_hooksInstalled{false};
std::atomic<bool> g_jsLoaded{false};
std::atomic<bool> g_menuVisible{false};
std::atomic<bool> g_menuNeedsRefresh{false};
std::atomic<bool> g_menuNeedsClose{false};
std::atomic<bool> g_companionEnabled{true};
std::atomic<bool> g_aiPickup{true};
std::atomic<bool> g_aiEquip{true};
std::atomic<bool> g_aiAssist{true};
std::atomic<bool> g_aiFollow{true};

struct SpawnedNpc {
    void* character;
    void* stage;
    bool enemy;
    uint64_t serial;
};

std::vector<SpawnedNpc> g_spawnedNpcs;
int g_selectedNpcType = 0;
bool g_selectedNpcEnemy = false;
uint64_t g_npcSerial = 0;
std::string g_menuStatus;
constexpr int kNpcTypeCount = 8;
const char* kNpcTypeLabels[kNpcTypeCount] = {
    "Герой", "Гоблин", "Нежить", "Орк", "Человек", "Тёмный", "Мальчик", "Алхимик"
};

using GameSceneInitFn = bool(*)(void*);
using GameSceneFrameMoveFn = void(*)(void*, float);
using UserInsFn = void*(*)(int);
using GetGameLevelFn = int(*)(void*);
using StageCreateMobFn = void*(*)(void*, int, int, int, int, int);
using StageRemoveMobFn = void(*)(void*, void*);
using GetCharacterNameFn = const char*(*)(int);
using CharacterSetTargetFn = void(*)(void*, void*);
using CharacterSetEnemyFn = void(*)(void*, bool);
using CharacterMoveToTargetFn = void(*)(void*);
using CharacterAttackAbleFn = bool(*)(void*, void*);
using CharacterAttackFn = bool(*)(void*, bool);
using CharacterSetVisibleFn = void(*)(void*, bool);
using NodeGetPositionFn = cocos2d::Vec2(*)(void*);
using NodeSetPositionFn = void(*)(void*, float, float);
using NodeAddChildFn = void(*)(void*, void*, int);
using NodeRemoveFn = void(*)(void*, bool);
using DirectorGetInstanceFn = void*(*)();
using DirectorGetWinSizeFn = cocos2d::Size(*)(void*);
using LayerColorCreateFn = void*(*)(const cocos2d::Color4B&, float, float);
using LabelCreateFn = void*(*)(const std::string&, const std::string&, float, const cocos2d::Size&, int, int);
using MenuItemCreateFn = void*(*)(void*, const std::function<void(cocos2d::Ref*)>&);
using MenuCreateWithItemFn = void*(*)(void*);
using FileUtilsGetInstanceFn = void*(*)();
using FileUtilsAddSearchPathFn = void(*)(void*, const std::string&, bool);

GameSceneInitFn g_originalInit = nullptr;
GameSceneFrameMoveFn g_originalFrameMove = nullptr;
UserInsFn g_userIns = nullptr;
GetGameLevelFn g_getGameLevel = nullptr;
StageCreateMobFn g_stageCreateMob = nullptr;
StageRemoveMobFn g_stageRemoveMob = nullptr;
GetCharacterNameFn g_getCharacterName = nullptr;
CharacterSetTargetFn g_setTarget = nullptr;
CharacterSetEnemyFn g_setEnemy = nullptr;
CharacterMoveToTargetFn g_moveToTarget = nullptr;
CharacterAttackAbleFn g_attackAble = nullptr;
CharacterAttackFn g_attack = nullptr;
CharacterSetVisibleFn g_setVisible = nullptr;
NodeGetPositionFn g_getPosition = nullptr;
NodeSetPositionFn g_setPosition = nullptr;
NodeAddChildFn g_addChild = nullptr;
NodeRemoveFn g_removeFromParent = nullptr;
DirectorGetInstanceFn g_directorGetInstance = nullptr;
DirectorGetWinSizeFn g_directorGetWinSize = nullptr;
LayerColorCreateFn g_layerColorCreate = nullptr;
LabelCreateFn g_labelCreate = nullptr;
MenuItemCreateFn g_menuItemCreate = nullptr;
MenuCreateWithItemFn g_menuCreateWithItem = nullptr;
FileUtilsGetInstanceFn g_fileUtilsGetInstance = nullptr;
FileUtilsAddSearchPathFn g_fileUtilsAddSearchPath = nullptr;
void* g_stageManagerStatic = nullptr;
void* g_userData = nullptr;

JSRuntime* g_jsRuntime = nullptr;
JSContext* g_jsContext = nullptr;
JSValue g_tickCallbacks;
bool g_tickCallbacksReady = false;
struct JsButton { std::string id; std::string label; std::string modId; std::string modName; JSValue callback; };
std::vector<JsButton> g_jsButtons;
std::string g_activeModId;
std::string g_activeModName;
std::string g_openModId;
std::string g_lastError;
std::atomic<int64_t> g_interruptDeadlineNs{0};
uint64_t g_cloneSerial = 0;

struct UiAction {
    int kind;
    size_t index;
};

int64_t nowNs() {
    timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return static_cast<int64_t>(ts.tv_sec) * 1000000000LL + ts.tv_nsec;
}

int jsInterrupt(JSRuntime*, void*) {
    const int64_t deadline = g_interruptDeadlineNs.load(std::memory_order_relaxed);
    return deadline > 0 && nowNs() > deadline;
}

std::string joinPath(const std::string& a, const std::string& b) {
    if (a.empty()) return b;
    if (a.back() == '/') return a + b;
    return a + "/" + b;
}

bool isDirectory(const std::string& path) {
    struct stat st{};
    return stat(path.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}

bool fileExists(const std::string& path) {
    struct stat st{};
    return stat(path.c_str(), &st) == 0 && S_ISREG(st.st_mode);
}

void makeDirectories(const std::string& path) {
    if (path.empty()) return;
    std::string current;
    current.reserve(path.size());
    for (size_t i = 0; i < path.size(); ++i) {
        current.push_back(path[i]);
        if (path[i] == '/' || i + 1 == path.size()) {
            if (current.size() > 1) mkdir(current.c_str(), 0700);
        }
    }
}

bool copyFileIfMissing(const std::string& source, const std::string& destination) {
    if (fileExists(destination)) return true;
    FILE* in = fopen(source.c_str(), "rb");
    if (!in) return false;
    FILE* out = fopen(destination.c_str(), "wb");
    if (!out) { fclose(in); return false; }
    unsigned char buffer[16384];
    size_t count = 0;
    bool ok = true;
    while ((count = fread(buffer, 1, sizeof(buffer), in)) > 0) {
        if (fwrite(buffer, 1, count, out) != count) { ok = false; break; }
    }
    fclose(in);
    fclose(out);
    return ok;
}

void copyAssetTree(AAssetManager* manager, const std::string& assetDir, const std::string& outDir) {
    makeDirectories(outDir);
    AAssetDir* dir = AAssetManager_openDir(manager, assetDir.c_str());
    if (!dir) return;
    const char* name = nullptr;
    while ((name = AAssetDir_getNextFileName(dir)) != nullptr) {
        const std::string childAsset = joinPath(assetDir, name);
        const std::string childOut = joinPath(outDir, name);
        AAsset* asset = AAssetManager_open(manager, childAsset.c_str(), AASSET_MODE_STREAMING);
        if (asset) {
            if (!fileExists(childOut)) {
                makeDirectories(outDir);
                FILE* out = fopen(childOut.c_str(), "wb");
                if (out) {
                    char buffer[16384];
                    int got = 0;
                    while ((got = AAsset_read(asset, buffer, sizeof(buffer))) > 0) {
                        if (fwrite(buffer, 1, static_cast<size_t>(got), out) != static_cast<size_t>(got)) break;
                    }
                    fclose(out);
                }
            }
            AAsset_close(asset);
        } else {
            copyAssetTree(manager, childAsset, childOut);
        }
    }
    AAssetDir_close(dir);
}


void copyDirectoryIfMissing(const std::string& source, const std::string& destination) {
    makeDirectories(destination);
    DIR* dir = opendir(source.c_str());
    if (!dir) return;
    dirent* ent = nullptr;
    while ((ent = readdir(dir)) != nullptr) {
        if (!strcmp(ent->d_name, ".") || !strcmp(ent->d_name, "..")) continue;
        const std::string src = joinPath(source, ent->d_name);
        const std::string dst = joinPath(destination, ent->d_name);
        if (isDirectory(src)) copyDirectoryIfMissing(src, dst);
        else copyFileIfMissing(src, dst);
    }
    closedir(dir);
}

void applyTextureSearchPaths() {
    if (!g_fileUtilsGetInstance || !g_fileUtilsAddSearchPath) return;
    void* utils = g_fileUtilsGetInstance();
    if (!utils) return;
    const std::string original = joinPath(g_basePath, "texture_pack/Original");
    const std::string active = joinPath(g_basePath, "texture_pack/Active");
    g_fileUtilsAddSearchPath(utils, original, false);
    g_fileUtilsAddSearchPath(utils, joinPath(original, "assets"), false);
    g_fileUtilsAddSearchPath(utils, active, true);
    g_fileUtilsAddSearchPath(utils, joinPath(active, "assets"), true);
}

void* resolve(const char* name) {
    if (!g_gameHandle) return nullptr;
    return dlsym(g_gameHandle, name);
}

void resolveGameSymbols() {
    g_originalInit = reinterpret_cast<GameSceneInitFn>(resolve("_ZN9GameScene4initEv"));
    g_originalFrameMove = reinterpret_cast<GameSceneFrameMoveFn>(resolve("_ZN9GameScene9FrameMoveEf"));
    g_userIns = reinterpret_cast<UserInsFn>(resolve("_ZN4User3InsE8UserType"));
    g_getGameLevel = reinterpret_cast<GetGameLevelFn>(resolve("_ZN8UserData12GetGameLevelEv"));
    g_stageCreateMob = reinterpret_cast<StageCreateMobFn>(resolve("_ZN5Stage9CreateMobE13CharacterTypeiiii"));
    g_stageRemoveMob = reinterpret_cast<StageRemoveMobFn>(resolve("_ZN5Stage9RemoveMobEP9Character"));
    g_getCharacterName = reinterpret_cast<GetCharacterNameFn>(resolve("_Z16GetCharacterName13CharacterType"));
    g_setTarget = reinterpret_cast<CharacterSetTargetFn>(resolve("_ZN9Character9SetTargetEPS_"));
    g_setEnemy = reinterpret_cast<CharacterSetEnemyFn>(resolve("_ZN9Character8SetEnemyEb"));
    g_moveToTarget = reinterpret_cast<CharacterMoveToTargetFn>(resolve("_ZN9Character12MoveToTargetEv"));
    g_attackAble = reinterpret_cast<CharacterAttackAbleFn>(resolve("_ZN9Character10AttackAbleEPS_"));
    g_attack = reinterpret_cast<CharacterAttackFn>(resolve("_ZN9Character6AttackEb"));
    g_setVisible = reinterpret_cast<CharacterSetVisibleFn>(resolve("_ZN9Character10SetVisibleEb"));
    g_getPosition = reinterpret_cast<NodeGetPositionFn>(resolve("_ZNK7cocos2d4Node11getPositionEv"));
    g_setPosition = reinterpret_cast<NodeSetPositionFn>(resolve("_ZN7cocos2d4Node11setPositionEff"));
    g_addChild = reinterpret_cast<NodeAddChildFn>(resolve("_ZN7cocos2d4Node8addChildEPS0_i"));
    g_removeFromParent = reinterpret_cast<NodeRemoveFn>(resolve("_ZN7cocos2d4Node26removeFromParentAndCleanupEb"));
    g_directorGetInstance = reinterpret_cast<DirectorGetInstanceFn>(resolve("_ZN7cocos2d8Director11getInstanceEv"));
    g_directorGetWinSize = reinterpret_cast<DirectorGetWinSizeFn>(resolve("_ZNK7cocos2d8Director10getWinSizeEv"));
    g_layerColorCreate = reinterpret_cast<LayerColorCreateFn>(resolve("_ZN7cocos2d10LayerColor6createERKNS_7Color4BEff"));
    g_labelCreate = reinterpret_cast<LabelCreateFn>(resolve("_ZN7cocos2d5Label20createWithSystemFontERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_fRKNS_4SizeENS_14TextHAlignmentENS_14TextVAlignmentE"));
    g_menuItemCreate = reinterpret_cast<MenuItemCreateFn>(resolve("_ZN7cocos2d13MenuItemLabel6createEPNS_4NodeERKNSt6__ndk18functionIFvPNS_3RefEEEE"));
    g_menuCreateWithItem = reinterpret_cast<MenuCreateWithItemFn>(resolve("_ZN7cocos2d4Menu14createWithItemEPNS_8MenuItemE"));
    g_fileUtilsGetInstance = reinterpret_cast<FileUtilsGetInstanceFn>(resolve("_ZN7cocos2d9FileUtils11getInstanceEv"));
    g_fileUtilsAddSearchPath = reinterpret_cast<FileUtilsAddSearchPathFn>(resolve("_ZN7cocos2d9FileUtils13addSearchPathERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEb"));
    g_stageManagerStatic = resolve("_ZZN8StageMgr3InsEvE8stageMgr");
    g_userData = resolve("g_UserData");
}

void logJsException(JSContext* ctx, const char* label) {
    JSValue exception = JS_GetException(ctx);
    const char* text = JS_ToCString(ctx, exception);
    LOGE("JS %s: %s", label, text ? text : "<unknown>");
    if (text) JS_FreeCString(ctx, text);
    JS_FreeValue(ctx, exception);
}

const char* jsString(JSContext* ctx, JSValueConst value) {
    return JS_ToCString(ctx, value);
}

void jsFreeString(JSContext* ctx, const char* value) {
    if (value) JS_FreeCString(ctx, value);
}

JSValue jsModRegister(JSContext* ctx, JSValueConst, int argc, JSValueConst* argv) {
    if (argc < 1 || !JS_IsObject(argv[0])) return JS_UNDEFINED;
    JSValue id = JS_GetPropertyStr(ctx, argv[0], "id");
    JSValue name = JS_GetPropertyStr(ctx, argv[0], "name");
    const char* idText = jsString(ctx, id);
    const char* nameText = jsString(ctx, name);
    if (idText) g_activeModId = idText;
    if (nameText) g_activeModName = nameText;
    jsFreeString(ctx, idText);
    jsFreeString(ctx, nameText);
    JS_FreeValue(ctx, id);
    JS_FreeValue(ctx, name);
    LOGI("Loaded mod: %s (%s)", g_activeModName.c_str(), g_activeModId.c_str());
    return JS_UNDEFINED;
}

JSValue jsUiNotify(JSContext* ctx, JSValueConst, int argc, JSValueConst* argv) {
    if (argc < 1) return JS_UNDEFINED;
    const char* text = jsString(ctx, argv[0]);
    if (text) LOGI("%s", text);
    jsFreeString(ctx, text);
    return JS_UNDEFINED;
}

JSValue jsUiAddButton(JSContext* ctx, JSValueConst, int argc, JSValueConst* argv) {
    if (argc < 3 || !JS_IsFunction(ctx, argv[2])) return JS_ThrowTypeError(ctx, "UI.addButton(id, label, callback) required");
    const char* id = jsString(ctx, argv[0]);
    const char* label = jsString(ctx, argv[1]);
    if (!id || !label) {
        jsFreeString(ctx, id);
        jsFreeString(ctx, label);
        return JS_ThrowTypeError(ctx, "id and label must be strings");
    }
    auto it = std::find_if(g_jsButtons.begin(), g_jsButtons.end(), [&](const JsButton& b) { return b.id == id; });
    if (it != g_jsButtons.end()) {
        JS_FreeValue(ctx, it->callback);
        it->label = label;
        it->modId = g_activeModId;
        it->modName = g_activeModName;
        it->callback = JS_DupValue(ctx, argv[2]);
    } else {
        g_jsButtons.push_back({id, label, g_activeModId, g_activeModName, JS_DupValue(ctx, argv[2])});
    }
    jsFreeString(ctx, id);
    jsFreeString(ctx, label);
    return JS_UNDEFINED;
}

JSValue jsLogInfo(JSContext* ctx, JSValueConst, int argc, JSValueConst* argv) {
    if (argc < 1) return JS_UNDEFINED;
    const char* text = jsString(ctx, argv[0]);
    if (text) LOGI("%s", text);
    jsFreeString(ctx, text);
    return JS_UNDEFINED;
}

JSValue jsLogError(JSContext* ctx, JSValueConst, int argc, JSValueConst* argv) {
    if (argc < 1) return JS_UNDEFINED;
    const char* text = jsString(ctx, argv[0]);
    if (text) LOGE("%s", text);
    jsFreeString(ctx, text);
    return JS_UNDEFINED;
}

bool stageVectorContains(void* stage, void* character) {
#if defined(__aarch64__)
    if (!stage || !character) return false;
    auto begin = *reinterpret_cast<uintptr_t**>(reinterpret_cast<uintptr_t>(stage) + kArm64StageMobsBeginOffset);
    auto end = *reinterpret_cast<uintptr_t**>(reinterpret_cast<uintptr_t>(stage) + kArm64StageMobsEndOffset);
    if (!begin || !end || end < begin || static_cast<size_t>(end - begin) > kMaxCharacters) return false;
    for (auto p = begin; p < end; ++p) if (reinterpret_cast<void*>(*p) == character) return true;
#endif
    return false;
}

void* currentPlayer() {
    if (!g_userIns) return nullptr;
    return g_userIns(0);
}

void* currentStage() {
#if defined(__aarch64__)
    if (!g_stageManagerStatic) return nullptr;
    return *reinterpret_cast<void**>(g_stageManagerStatic);
#else
    return nullptr;
#endif
}

bool spawnClone(std::string* outId) {
#if defined(__aarch64__)
    if (!g_stageCreateMob || !g_userIns || !g_getPosition || !g_setEnemy || !g_setTarget || !g_moveToTarget || !g_userData || !g_getGameLevel) {
        g_lastError = "Игровой API клона не найден";
        return false;
    }
    void* stage = currentStage();
    void* player = currentPlayer();
    if (!stage || !player) {
        g_lastError = "Сначала начни игровой уровень";
        return false;
    }
    if (g_clone && g_cloneStage == stage && stageVectorContains(stage, g_clone)) {
        g_lastError = "Клон уже существует";
        return false;
    }
    const int characterType = *reinterpret_cast<int*>(reinterpret_cast<uintptr_t>(player) + kArm64CharacterTypeOffset);
    const int level = std::max(1, g_getGameLevel(g_userData));
    const cocos2d::Vec2 playerPos = g_getPosition(player);
    void* clone = g_stageCreateMob(stage, characterType, level, static_cast<int>(std::lround(playerPos.x + 44.0f)), static_cast<int>(std::lround(playerPos.y)), 0);
    if (!clone) {
        g_lastError = "Игра не создала персонажа-клона";
        return false;
    }
    g_setEnemy(clone, false);
    g_setTarget(clone, player);
    g_moveToTarget(clone);
    g_clone = clone;
    g_cloneStage = stage;
    g_player = player;
    ++g_cloneSerial;
    if (outId) *outId = "clone_" + std::to_string(g_cloneSerial);
    g_lastError.clear();
    LOGI("Companion spawned type=%d level=%d ptr=%p", characterType, level, clone);
    return true;
#else
    (void)outId;
    g_lastError = "Призыв клона в этой версии доступен только на ARM64";
    return false;
#endif
}

bool despawnClone() {
#if defined(__aarch64__)
    if (!g_clone) return false;
    void* stage = currentStage();
    if (stage && stage == g_cloneStage && stageVectorContains(stage, g_clone) && g_stageRemoveMob) {
        g_stageRemoveMob(stage, g_clone);
    } else if (g_setVisible) {
        g_setVisible(g_clone, false);
    }
    g_clone = nullptr;
    g_cloneStage = nullptr;
    g_player = nullptr;
    return true;
#else
    return false;
#endif
}

const char* npcTypeLabel(int type) {
    if (type < 0 || type >= kNpcTypeCount) return "Неизвестный";
    return kNpcTypeLabels[type];
}

bool spawnNpc(int type, bool enemy, std::string* outId) {
#if defined(__aarch64__)
    if (type < 0 || type >= kNpcTypeCount || !g_getCharacterName || !g_getCharacterName(type)) {
        g_lastError = "Неизвестный тип NPC";
        return false;
    }
    if (!g_stageCreateMob || !g_userIns || !g_getPosition || !g_setEnemy || !g_userData || !g_getGameLevel) {
        g_lastError = "Игровой API создания NPC не найден";
        return false;
    }
    void* stage = currentStage();
    void* player = currentPlayer();
    if (!stage || !player) {
        g_lastError = "Сначала начни игровой уровень";
        return false;
    }
    if (g_spawnedNpcs.size() >= 12) {
        g_lastError = "Лимит NPC: 12. Удали созданных NPC";
        return false;
    }
    const int level = std::max(1, g_getGameLevel(g_userData));
    const cocos2d::Vec2 pos = g_getPosition(player);
    const float offset = 64.0f + static_cast<float>(g_spawnedNpcs.size() % 4) * 28.0f;
    void* npc = g_stageCreateMob(stage, type, level,
        static_cast<int>(std::lround(pos.x + offset)),
        static_cast<int>(std::lround(pos.y)), 0);
    if (!npc) {
        g_lastError = "Игра не создала NPC этого типа";
        return false;
    }
    g_setEnemy(npc, enemy);
    if (g_setTarget) g_setTarget(npc, player);
    if (g_moveToTarget) g_moveToTarget(npc);
    const uint64_t serial = ++g_npcSerial;
    g_spawnedNpcs.push_back({npc, stage, enemy, serial});
    if (outId) *outId = "npc_" + std::to_string(serial);
    g_lastError.clear();
    LOGI("NPC spawned type=%d (%s) faction=%s ptr=%p", type, g_getCharacterName(type), enemy ? "enemy" : "friend", npc);
    return true;
#else
    (void)type;
    (void)enemy;
    (void)outId;
    g_lastError = "Создание NPC доступно только на ARM64";
    return false;
#endif
}

bool removeNpcBySerial(uint64_t serial) {
#if defined(__aarch64__)
    for (auto it = g_spawnedNpcs.begin(); it != g_spawnedNpcs.end(); ++it) {
        if (it->serial != serial) continue;
        void* stage = currentStage();
        if (stage && stage == it->stage && stageVectorContains(stage, it->character) && g_stageRemoveMob) {
            g_stageRemoveMob(stage, it->character);
        }
        g_spawnedNpcs.erase(it);
        return true;
    }
#endif
    return false;
}

int removeAllNpcs() {
    int removed = 0;
    while (!g_spawnedNpcs.empty()) {
        const uint64_t serial = g_spawnedNpcs.back().serial;
        if (removeNpcBySerial(serial)) ++removed;
        else g_spawnedNpcs.pop_back();
    }
    return removed;
}

void spawnedNpcsTick(float dt) {
#if defined(__aarch64__)
    static float accumulated = 0.0f;
    accumulated += std::max(0.0f, dt);
    if (accumulated < 0.35f) return;
    accumulated = 0.0f;
    void* stage = currentStage();
    void* player = currentPlayer();
    if (!stage || !player || !g_getPosition) return;
    const cocos2d::Vec2 playerPos = g_getPosition(player);
    for (auto it = g_spawnedNpcs.begin(); it != g_spawnedNpcs.end();) {
        if (it->stage != stage || !stageVectorContains(stage, it->character)) {
            it = g_spawnedNpcs.erase(it);
            continue;
        }
        void* npc = it->character;
        if (it->enemy) {
            if (g_setTarget) g_setTarget(npc, player);
            if (g_attackAble && g_attack && g_attackAble(npc, player)) g_attack(npc, false);
            else if (g_moveToTarget) g_moveToTarget(npc);
        } else {
            void* nearest = nullptr;
            float nearestDistance = 1.0e9f;
            if (g_attackAble) {
                auto begin = *reinterpret_cast<uintptr_t**>(reinterpret_cast<uintptr_t>(stage) + kArm64StageMobsBeginOffset);
                auto end = *reinterpret_cast<uintptr_t**>(reinterpret_cast<uintptr_t>(stage) + kArm64StageMobsEndOffset);
                if (begin && end && end >= begin && static_cast<size_t>(end - begin) <= kMaxCharacters) {
                    for (auto q = begin; q < end; ++q) {
                        void* candidate = reinterpret_cast<void*>(*q);
                        if (!candidate || candidate == npc || candidate == player || !g_attackAble(npc, candidate)) continue;
                        const cocos2d::Vec2 p = g_getPosition(candidate);
                        const float dx = p.x - playerPos.x;
                        const float dy = p.y - playerPos.y;
                        const float distance = std::sqrt(dx * dx + dy * dy);
                        if (distance < nearestDistance && distance < 520.0f) {
                            nearestDistance = distance;
                            nearest = candidate;
                        }
                    }
                }
            }
            if (nearest && g_setTarget && g_attack) {
                g_setTarget(npc, nearest);
                g_attack(npc, false);
            } else if (g_aiFollow.load() && g_setTarget && g_moveToTarget) {
                const cocos2d::Vec2 npcPos = g_getPosition(npc);
                const float dx = npcPos.x - playerPos.x;
                const float dy = npcPos.y - playerPos.y;
                if (dx * dx + dy * dy > 90.0f * 90.0f) {
                    g_setTarget(npc, player);
                    g_moveToTarget(npc);
                }
            }
        }
        ++it;
    }
#endif
}

JSValue jsWorldSpawnNpc(JSContext* ctx, JSValueConst, int argc, JSValueConst* argv) {
    int type = g_selectedNpcType;
    bool enemy = g_selectedNpcEnemy;
    if (argc > 0 && JS_IsObject(argv[0])) {
        JSValue value = JS_GetPropertyStr(ctx, argv[0], "type");
        if (!JS_IsUndefined(value)) JS_ToInt32(ctx, &type, value);
        JS_FreeValue(ctx, value);
        value = JS_GetPropertyStr(ctx, argv[0], "enemy");
        if (!JS_IsUndefined(value)) enemy = JS_ToBool(ctx, value) != 0;
        JS_FreeValue(ctx, value);
    }
    std::string id;
    if (!spawnNpc(type, enemy, &id)) return JS_ThrowInternalError(ctx, "%s", g_lastError.c_str());
    return JS_NewString(ctx, id.c_str());
}

JSValue jsWorldRemoveNpc(JSContext* ctx, JSValueConst, int argc, JSValueConst* argv) {
    if (argc < 1) return JS_NewBool(ctx, false);
    const char* id = jsString(ctx, argv[0]);
    if (!id) return JS_NewBool(ctx, false);
    bool removed = false;
    if (!strncmp(id, "npc_", 4)) {
        char* end = nullptr;
        const unsigned long long serial = strtoull(id + 4, &end, 10);
        if (end && *end == '\0' && serial > 0) removed = removeNpcBySerial(static_cast<uint64_t>(serial));
    }
    jsFreeString(ctx, id);
    return JS_NewBool(ctx, removed);
}

JSValue jsWorldRemoveAllNpcs(JSContext* ctx, JSValueConst, int, JSValueConst*) {
    return JS_NewInt32(ctx, removeAllNpcs());
}

JSValue jsWorldGetNpcSelection(JSContext* ctx, JSValueConst, int, JSValueConst*) {
    JSValue value = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, value, "type", JS_NewInt32(ctx, g_selectedNpcType));
    JS_SetPropertyStr(ctx, value, "enemy", JS_NewBool(ctx, g_selectedNpcEnemy));
    return value;
}

JSValue jsWorldSetNpcSelection(JSContext* ctx, JSValueConst, int argc, JSValueConst* argv) {
    if (argc < 1 || !JS_IsObject(argv[0])) return JS_ThrowTypeError(ctx, "World.setNpcSelection({type, enemy}) required");
    JSValue typeValue = JS_GetPropertyStr(ctx, argv[0], "type");
    if (!JS_IsUndefined(typeValue)) {
        int type = g_selectedNpcType;
        JS_ToInt32(ctx, &type, typeValue);
        if (type < 0 || type >= kNpcTypeCount) {
            JS_FreeValue(ctx, typeValue);
            return JS_ThrowTypeError(ctx, "NPC type must be between 0 and 7");
        }
        g_selectedNpcType = type;
    }
    JS_FreeValue(ctx, typeValue);
    JSValue enemyValue = JS_GetPropertyStr(ctx, argv[0], "enemy");
    if (!JS_IsUndefined(enemyValue)) g_selectedNpcEnemy = JS_ToBool(ctx, enemyValue) != 0;
    JS_FreeValue(ctx, enemyValue);
    return JS_NewBool(ctx, true);
}

JSValue jsWorldGetNpcTypes(JSContext* ctx, JSValueConst, int, JSValueConst*) {
    JSValue array = JS_NewArray(ctx);
    for (int i = 0; i < kNpcTypeCount; ++i) {
        JSValue item = JS_NewObject(ctx);
        JS_SetPropertyStr(ctx, item, "id", JS_NewInt32(ctx, i));
        const char* name = g_getCharacterName ? g_getCharacterName(i) : nullptr;
        JS_SetPropertyStr(ctx, item, "name", JS_NewString(ctx, name ? name : npcTypeLabel(i)));
        JS_SetPropertyUint32(ctx, array, static_cast<uint32_t>(i), item);
    }
    return array;
}

JSValue jsWorldSpawnClone(JSContext* ctx, JSValueConst, int, JSValueConst*) {
    std::string id;
    if (!spawnClone(&id)) return JS_ThrowInternalError(ctx, "%s", g_lastError.c_str());
    return JS_NewString(ctx, id.c_str());
}

JSValue jsWorldDespawnClone(JSContext* ctx, JSValueConst, int, JSValueConst*) {
    return JS_NewBool(ctx, despawnClone());
}

JSValue jsWorldSetCloneAI(JSContext* ctx, JSValueConst, int argc, JSValueConst* argv) {
    if (argc < 2 || !JS_IsObject(argv[1])) return JS_ThrowTypeError(ctx, "World.setCloneAI(id, settings) required");
    auto readBool = [&](const char* key, std::atomic<bool>& target) {
        JSValue value = JS_GetPropertyStr(ctx, argv[1], key);
        if (!JS_IsUndefined(value)) target.store(JS_ToBool(ctx, value) != 0);
        JS_FreeValue(ctx, value);
    };
    readBool("follow", g_aiFollow);
    readBool("pickup", g_aiPickup);
    readBool("equipBetter", g_aiEquip);
    readBool("assistEnemies", g_aiAssist);
    return JS_UNDEFINED;
}

JSValue jsWorldGetCloneState(JSContext* ctx, JSValueConst, int, JSValueConst*) {
    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, obj, "active", JS_NewBool(ctx, g_clone != nullptr));
    JS_SetPropertyStr(ctx, obj, "follow", JS_NewBool(ctx, g_aiFollow.load()));
    JS_SetPropertyStr(ctx, obj, "pickup", JS_NewBool(ctx, g_aiPickup.load()));
    JS_SetPropertyStr(ctx, obj, "equipBetter", JS_NewBool(ctx, g_aiEquip.load()));
    JS_SetPropertyStr(ctx, obj, "assistEnemies", JS_NewBool(ctx, g_aiAssist.load()));
    return obj;
}

JSValue jsPlayerGetPosition(JSContext* ctx, JSValueConst, int, JSValueConst*) {
    void* player = currentPlayer();
    if (!player || !g_getPosition) return JS_NULL;
    const cocos2d::Vec2 p = g_getPosition(player);
    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, obj, "x", JS_NewFloat64(ctx, p.x));
    JS_SetPropertyStr(ctx, obj, "y", JS_NewFloat64(ctx, p.y));
    return obj;
}

JSValue jsEventsOn(JSContext* ctx, JSValueConst, int argc, JSValueConst* argv) {
    if (argc < 2 || !JS_IsFunction(ctx, argv[1])) return JS_ThrowTypeError(ctx, "Events.on(name, callback) required");
    const char* name = jsString(ctx, argv[0]);
    if (!name) return JS_ThrowTypeError(ctx, "event name must be string");
    if (!strcmp(name, "tick")) {
        if (!g_tickCallbacksReady) {
            g_tickCallbacks = JS_NewArray(ctx);
            g_tickCallbacksReady = true;
        }
        uint32_t index = 0;
        JSValue len = JS_GetPropertyStr(ctx, g_tickCallbacks, "length");
        JS_ToUint32(ctx, &index, len);
        JS_FreeValue(ctx, len);
        JS_SetPropertyUint32(ctx, g_tickCallbacks, index, JS_DupValue(ctx, argv[1]));
    }
    jsFreeString(ctx, name);
    return JS_UNDEFINED;
}

JSValue jsEventsOff(JSContext* ctx, JSValueConst, int argc, JSValueConst* argv) {
    if (!g_tickCallbacksReady || argc < 1) return JS_UNDEFINED;
    const char* name = jsString(ctx, argv[0]);
    if (name && !strcmp(name, "tick")) {
        JS_FreeValue(ctx, g_tickCallbacks);
        g_tickCallbacks = JS_NewArray(ctx);
    }
    jsFreeString(ctx, name);
    return JS_UNDEFINED;
}

void setObjectFunction(JSContext* ctx, JSValue obj, const char* name, JSCFunction* fn, int argc) {
    JS_SetPropertyStr(ctx, obj, name, JS_NewCFunction(ctx, fn, name, argc));
}

void registerJsApi() {
    if (!g_jsContext) return;
    JSValue global = JS_GetGlobalObject(g_jsContext);
    JSValue mod = JS_NewObject(g_jsContext);
    setObjectFunction(g_jsContext, mod, "register", jsModRegister, 1);
    JS_SetPropertyStr(g_jsContext, global, "Mod", mod);

    JSValue ui = JS_NewObject(g_jsContext);
    setObjectFunction(g_jsContext, ui, "notify", jsUiNotify, 1);
    setObjectFunction(g_jsContext, ui, "addButton", jsUiAddButton, 3);
    JS_SetPropertyStr(g_jsContext, global, "UI", ui);

    JSValue world = JS_NewObject(g_jsContext);
    setObjectFunction(g_jsContext, world, "spawnClone", jsWorldSpawnClone, 1);
    setObjectFunction(g_jsContext, world, "spawnNpc", jsWorldSpawnNpc, 1);
    setObjectFunction(g_jsContext, world, "removeNpc", jsWorldRemoveNpc, 1);
    setObjectFunction(g_jsContext, world, "removeAllNpcs", jsWorldRemoveAllNpcs, 0);
    setObjectFunction(g_jsContext, world, "getNpcTypes", jsWorldGetNpcTypes, 0);
    setObjectFunction(g_jsContext, world, "getNpcSelection", jsWorldGetNpcSelection, 0);
    setObjectFunction(g_jsContext, world, "setNpcSelection", jsWorldSetNpcSelection, 1);
    setObjectFunction(g_jsContext, world, "despawnClone", jsWorldDespawnClone, 1);
    setObjectFunction(g_jsContext, world, "setCloneAI", jsWorldSetCloneAI, 2);
    setObjectFunction(g_jsContext, world, "getCloneState", jsWorldGetCloneState, 0);
    JS_SetPropertyStr(g_jsContext, global, "World", world);

    JSValue player = JS_NewObject(g_jsContext);
    setObjectFunction(g_jsContext, player, "getPosition", jsPlayerGetPosition, 0);
    JS_SetPropertyStr(g_jsContext, global, "Player", player);

    JSValue events = JS_NewObject(g_jsContext);
    setObjectFunction(g_jsContext, events, "on", jsEventsOn, 2);
    setObjectFunction(g_jsContext, events, "off", jsEventsOff, 1);
    JS_SetPropertyStr(g_jsContext, global, "Events", events);

    JSValue logger = JS_NewObject(g_jsContext);
    setObjectFunction(g_jsContext, logger, "info", jsLogInfo, 1);
    setObjectFunction(g_jsContext, logger, "error", jsLogError, 1);
    JS_SetPropertyStr(g_jsContext, global, "Logger", logger);
    JS_FreeValue(g_jsContext, global);
}

bool evaluateFile(const std::string& path) {
    FILE* file = fopen(path.c_str(), "rb");
    if (!file) return false;
    fseek(file, 0, SEEK_END);
    long size = ftell(file);
    fseek(file, 0, SEEK_SET);
    if (size <= 0 || size > 512 * 1024) { fclose(file); LOGW("Skip invalid JS file %s", path.c_str()); return false; }
    std::string source(static_cast<size_t>(size), '\0');
    const size_t read = fread(source.data(), 1, source.size(), file);
    fclose(file);
    if (read != source.size()) return false;
    std::string wrapped;
    wrapped.reserve(source.size() + 24);
    wrapped = "(function(){\n";
    wrapped += source;
    wrapped += "\n})();";
    g_interruptDeadlineNs.store(nowNs() + 100000000LL);
    JSValue result = JS_Eval(g_jsContext, wrapped.c_str(), wrapped.size(), path.c_str(), JS_EVAL_TYPE_GLOBAL);
    g_interruptDeadlineNs.store(0);
    if (JS_IsException(result)) {
        logJsException(g_jsContext, path.c_str());
        JS_FreeValue(g_jsContext, result);
        return false;
    }
    JS_FreeValue(g_jsContext, result);
    return true;
}

void loadScriptDirectories(const std::string& root) {
    DIR* dir = opendir(root.c_str());
    if (!dir) return;
    dirent* ent = nullptr;
    while ((ent = readdir(dir)) != nullptr) {
        if (ent->d_name[0] == '.') continue;
        const std::string modDir = joinPath(root, ent->d_name);
        if (!isDirectory(modDir)) continue;
        const std::string entry = joinPath(modDir, "main.js");
        if (fileExists(entry)) {
            const bool loaded = evaluateFile(entry);
            LOGI("Script %s: %s", entry.c_str(), loaded ? "loaded" : "failed");
        }
    }
    closedir(dir);
}

void loadAllScripts() {
    if (g_jsLoaded.exchange(true)) return;
    g_jsRuntime = JS_NewRuntime();
    if (!g_jsRuntime) { g_jsLoaded.store(false); LOGE("QuickJS runtime create failed"); return; }
    JS_SetMemoryLimit(g_jsRuntime, 8 * 1024 * 1024);
    JS_SetMaxStackSize(g_jsRuntime, 512 * 1024);
    JS_SetInterruptHandler(g_jsRuntime, jsInterrupt, nullptr);
    g_jsContext = JS_NewContext(g_jsRuntime);
    if (!g_jsContext) { JS_FreeRuntime(g_jsRuntime); g_jsRuntime = nullptr; g_jsLoaded.store(false); return; }
    registerJsApi();
    g_tickCallbacks = JS_NewArray(g_jsContext);
    g_tickCallbacksReady = true;
    loadScriptDirectories(joinPath(g_basePath, "Scripts"));
    loadScriptDirectories(joinPath(g_basePath, "Mods"));
    LOGI("JavaScript mods loaded");
}

void invokeJsButton(size_t index) {
    if (!g_jsContext || index >= g_jsButtons.size()) return;
    g_interruptDeadlineNs.store(nowNs() + 30000000LL);
    JSValue result = JS_Call(g_jsContext, g_jsButtons[index].callback, JS_UNDEFINED, 0, nullptr);
    g_interruptDeadlineNs.store(0);
    if (JS_IsException(result)) logJsException(g_jsContext, g_jsButtons[index].id.c_str());
    JS_FreeValue(g_jsContext, result);
}

void invokeTickCallbacks(float dt) {
    if (!g_jsContext || !g_tickCallbacksReady) return;
    JSValue callbacks = JS_DupValue(g_jsContext, g_tickCallbacks);
    JSValue lenValue = JS_GetPropertyStr(g_jsContext, callbacks, "length");
    uint32_t count = 0;
    JS_ToUint32(g_jsContext, &count, lenValue);
    JS_FreeValue(g_jsContext, lenValue);
    JSValue arg = JS_NewFloat64(g_jsContext, dt);
    g_interruptDeadlineNs.store(nowNs() + 3000000LL);
    for (uint32_t i = 0; i < count; ++i) {
        JSValue callback = JS_GetPropertyUint32(g_jsContext, callbacks, i);
        JSValue result = JS_Call(g_jsContext, callback, JS_UNDEFINED, 1, &arg);
        const bool failed = JS_IsException(result);
        JS_FreeValue(g_jsContext, result);
        JS_FreeValue(g_jsContext, callback);
        if (failed) logJsException(g_jsContext, "tick");
    }
    g_interruptDeadlineNs.store(0);
    JS_FreeValue(g_jsContext, arg);
    JS_FreeValue(g_jsContext, callbacks);
}

void* createLabel(const std::string& text, float fontSize) {
    if (!g_labelCreate) return nullptr;
    const std::string font = "Arial";
    const cocos2d::Size noLimit{0.0f, 0.0f};
    return g_labelCreate(text, font, fontSize, noLimit, 1, 1);
}

void addMenuEntry(void* parent, const std::string& text, float x, float y, std::function<void(cocos2d::Ref*)> callback, int z) {
    if (!parent || !g_menuItemCreate || !g_menuCreateWithItem || !g_addChild || !g_setPosition) return;
    void* label = createLabel(text, 18.0f);
    if (!label) return;
    void* item = g_menuItemCreate(label, callback);
    if (!item) return;
    void* menu = g_menuCreateWithItem(item);
    if (!menu) return;
    g_setPosition(menu, x, y);
    g_addChild(parent, menu, z);
}

void closeMenu() {
    if (g_menuPanel && g_removeFromParent) g_removeFromParent(g_menuPanel, true);
    if (g_menuBackdrop && g_removeFromParent) g_removeFromParent(g_menuBackdrop, true);
    g_menuPanel = nullptr;
    g_menuBackdrop = nullptr;
    g_menuVisible.store(false);
}

void openMenu();

void reloadScripts() {
    if (g_jsContext) {
        for (auto& button : g_jsButtons) JS_FreeValue(g_jsContext, button.callback);
        g_jsButtons.clear();
        if (g_tickCallbacksReady) JS_FreeValue(g_jsContext, g_tickCallbacks);
        g_tickCallbacksReady = false;
        JS_FreeContext(g_jsContext);
        g_jsContext = nullptr;
    }
    g_jsButtons.clear();
    g_activeModId.clear();
    g_activeModName.clear();
    if (g_jsRuntime) {
        JS_FreeRuntime(g_jsRuntime);
        g_jsRuntime = nullptr;
    }
    g_jsLoaded.store(false);
    loadAllScripts();
}

void runNativeCloneButton() {
    if (g_clone) {
        despawnClone();
        return;
    }
    std::string id;
    if (!spawnClone(&id)) LOGW("Clone: %s", g_lastError.c_str());
}

void refreshMenu() {
    g_menuNeedsRefresh.store(true);
}

void openMenu() {
    if (!g_currentScene || !g_directorGetInstance || !g_directorGetWinSize || !g_layerColorCreate || !g_addChild || !g_setPosition) {
        LOGW("Menu open aborted: Cocos UI symbols are unavailable");
        return;
    }
    if (g_menuPanel) { closeMenu(); return; }
    void* director = g_directorGetInstance();
    if (!director) { LOGW("Menu open aborted: Director is null"); return; }
    const cocos2d::Size win = g_directorGetWinSize(director);

    const cocos2d::Color4B shade{0, 0, 0, 150};
    g_menuBackdrop = g_layerColorCreate(shade, win.width, win.height);
    if (g_menuBackdrop) {
        g_setPosition(g_menuBackdrop, 0.0f, 0.0f);
        g_addChild(g_currentScene, g_menuBackdrop, 29999);
    }

    const float width = std::min(win.width * 0.82f, 520.0f);
    const float height = std::min(win.height * 0.82f, 620.0f);
    const cocos2d::Color4B color{13, 19, 31, 248};
    void* panel = g_layerColorCreate(color, width, height);
    if (!panel) {
        if (g_menuBackdrop && g_removeFromParent) g_removeFromParent(g_menuBackdrop, true);
        g_menuBackdrop = nullptr;
        LOGE("LayerColor::create failed");
        return;
    }
    g_menuPanel = panel;
    g_setPosition(g_menuPanel, (win.width - width) * 0.5f, (win.height - height) * 0.5f);
    g_addChild(g_currentScene, g_menuPanel, 30000);

    std::string selectedModName;
    if (!g_openModId.empty()) {
        for (const auto& button : g_jsButtons) {
            if (button.modId == g_openModId) { selectedModName = button.modName; break; }
        }
    }
    void* title = createLabel("CLEO  |  NST MOD MENU", 23.0f);
    if (title) {
        g_setPosition(title, width * 0.5f, height - 34.0f);
        g_addChild(g_menuPanel, title, 4);
    }
    const std::string subtitleText = g_openModId.empty() ? "УСТАНОВЛЕННЫЕ МОДЫ" : selectedModName;
    void* subtitle = createLabel(subtitleText, 14.0f);
    if (subtitle) {
        g_setPosition(subtitle, width * 0.5f, height - 61.0f);
        g_addChild(g_menuPanel, subtitle, 4);
    }
    if (!g_menuStatus.empty()) {
        void* status = createLabel(g_menuStatus, 12.0f);
        if (status) {
            g_setPosition(status, width * 0.5f, height - 84.0f);
            g_addChild(g_menuPanel, status, 4);
        }
    }

    const float center = width * 0.5f;
    const float gap = std::min(42.0f, std::max(27.0f, (height - 150.0f) / 9.0f));
    float y = height - 112.0f;

    if (g_openModId.empty()) {
        std::vector<std::pair<std::string, std::string>> mods;
        for (const auto& button : g_jsButtons) {
            const std::string id = button.modId.empty() ? "__unregistered__" : button.modId;
            const std::string name = button.modName.empty() ? "Скрипты без названия" : button.modName;
            auto found = std::find_if(mods.begin(), mods.end(), [&](const auto& item) { return item.first == id; });
            if (found == mods.end()) mods.push_back({id, name});
        }
        if (mods.empty()) {
            void* empty = createLabel("Моды не найдены. Добавь папку мода с main.js в Scripts или Mods.", 12.0f);
            if (empty) {
                g_setPosition(empty, center, y);
                g_addChild(g_menuPanel, empty, 4);
            }
            y -= gap;
        } else {
            const size_t count = std::min<size_t>(9, mods.size());
            for (size_t i = 0; i < count; ++i) {
                const std::string modId = mods[i].first;
                const std::string modName = mods[i].second;
                addMenuEntry(g_menuPanel, modName + "  >", center, y, [modId](cocos2d::Ref*) {
                    g_openModId = modId;
                    g_menuStatus.clear();
                    refreshMenu();
                }, 5);
                y -= gap;
            }
        }
    } else {
        if (g_openModId == "npc_spawner") {
            const std::string selection = std::string("NPC: ") + npcTypeLabel(g_selectedNpcType) +
                (g_selectedNpcEnemy ? "  |  ПРОТИВНИК" : "  |  ДРУГ");
            void* selected = createLabel(selection, 13.0f);
            if (selected) {
                g_setPosition(selected, center, y);
                g_addChild(g_menuPanel, selected, 4);
            }
            y -= gap;
        }
        size_t shown = 0;
        for (size_t i = 0; i < g_jsButtons.size() && shown < 8; ++i) {
            if (g_jsButtons[i].modId != g_openModId && !(g_openModId == "__unregistered__" && g_jsButtons[i].modId.empty())) continue;
            const size_t index = i;
            addMenuEntry(g_menuPanel, g_jsButtons[i].label, center, y, [index](cocos2d::Ref*) {
                invokeJsButton(index);
                if (index < g_jsButtons.size()) g_menuStatus = "Выполнено: " + g_jsButtons[index].label;
                refreshMenu();
            }, 5);
            y -= gap;
            ++shown;
        }
        if (shown == 0) {
            void* empty = createLabel("В этом моде нет доступных действий.", 12.0f);
            if (empty) {
                g_setPosition(empty, center, y);
                g_addChild(g_menuPanel, empty, 4);
            }
            y -= gap;
        }
        addMenuEntry(g_menuPanel, "< НАЗАД К СПИСКУ МОДОВ", center, std::max(65.0f, y - 4.0f), [](cocos2d::Ref*) {
            g_openModId.clear();
            g_menuStatus.clear();
            refreshMenu();
        }, 5);
        y -= gap;
    }

    addMenuEntry(g_menuPanel, "ПЕРЕЗАГРУЗИТЬ МОДЫ", center, std::max(54.0f, y - 8.0f), [](cocos2d::Ref*) {
        reloadScripts();
        g_openModId.clear();
        g_menuStatus = "Скрипты перечитаны";
        refreshMenu();
    }, 5);
    addMenuEntry(g_menuPanel, "ЗАКРЫТЬ", center, 22.0f, [](cocos2d::Ref*) { g_menuNeedsClose.store(true); }, 5);
    g_menuVisible.store(true);
    LOGI("CLEO-style menu opened; mods=%u actions=%u npc=%u", static_cast<unsigned>(g_jsButtons.size()), static_cast<unsigned>(g_jsButtons.size()), static_cast<unsigned>(g_spawnedNpcs.size()));
}

void createMenuButton(void* scene) {
    if (!scene || g_menuButton || !g_menuItemCreate || !g_menuCreateWithItem || !g_addChild || !g_setPosition || !g_directorGetInstance || !g_directorGetWinSize) return;
    void* director = g_directorGetInstance();
    if (!director) return;
    const cocos2d::Size win = g_directorGetWinSize(director);
    void* label = createLabel("МОДЫ", 17.0f);
    if (!label) return;
    auto callback = [](cocos2d::Ref*) { LOGI("Mods button tapped"); openMenu(); };
    void* item = g_menuItemCreate(label, callback);
    if (!item) return;
    g_menuButton = g_menuCreateWithItem(item);
    if (!g_menuButton) return;
    g_setPosition(g_menuButton, 58.0f, std::max(42.0f, win.height - 46.0f));
    g_addChild(scene, g_menuButton, 30000);
    LOGI("Mods button created at left corner: %.1f, %.1f", 58.0f, std::max(42.0f, win.height - 46.0f));
}

void companionTick(float dt) {
#if defined(__aarch64__)
    static float accumulated = 0.0f;
    accumulated += std::max(0.0f, dt);
    if (accumulated < 0.30f) return;
    accumulated = 0.0f;
    if (!g_clone || !g_companionEnabled.load()) return;
    void* stage = currentStage();
    void* player = currentPlayer();
    if (!stage || !player || stage != g_cloneStage || !stageVectorContains(stage, g_clone)) {
        g_clone = nullptr;
        g_cloneStage = nullptr;
        g_player = nullptr;
        return;
    }
    const cocos2d::Vec2 playerPos = g_getPosition ? g_getPosition(player) : cocos2d::Vec2{0, 0};
    void* nearest = nullptr;
    float nearestDistance = 1.0e9f;
    if (g_aiAssist.load() && g_attackAble && g_getPosition) {
        auto begin = *reinterpret_cast<uintptr_t**>(reinterpret_cast<uintptr_t>(stage) + kArm64StageMobsBeginOffset);
        auto end = *reinterpret_cast<uintptr_t**>(reinterpret_cast<uintptr_t>(stage) + kArm64StageMobsEndOffset);
        if (begin && end && end >= begin && static_cast<size_t>(end - begin) <= kMaxCharacters) {
            for (auto p = begin; p < end; ++p) {
                void* candidate = reinterpret_cast<void*>(*p);
                if (!candidate || candidate == g_clone || candidate == player) continue;
                if (!g_attackAble(g_clone, candidate)) continue;
                const cocos2d::Vec2 pos = g_getPosition(candidate);
                const float dx = pos.x - playerPos.x;
                const float dy = pos.y - playerPos.y;
                const float distance = std::sqrt(dx * dx + dy * dy);
                if (distance < nearestDistance && distance < 520.0f) {
                    nearestDistance = distance;
                    nearest = candidate;
                }
            }
        }
    }
    if (nearest && g_setTarget && g_attack) {
        g_setTarget(g_clone, nearest);
        g_attack(g_clone, false);
    } else if (g_aiFollow.load() && g_setTarget && g_moveToTarget) {
        g_setTarget(g_clone, player);
        g_moveToTarget(g_clone);
    }
#endif
}

bool hookedGameSceneInit(void* self) {
    applyTextureSearchPaths();
    const bool result = g_originalInit ? g_originalInit(self) : false;
    if (result) {
        g_currentScene = self;
        g_menuButton = nullptr;
        g_menuPanel = nullptr;
        g_menuBackdrop = nullptr;
        g_openModId.clear();
        g_menuVisible.store(false);
        g_menuNeedsRefresh.store(false);
        g_menuNeedsClose.store(false);
        loadAllScripts();
        createMenuButton(self);
        LOGI("GameScene init hook ready");
    }
    return result;
}

void hookedGameSceneFrameMove(void* self, float dt) {
    if (g_originalFrameMove) g_originalFrameMove(self, dt);
    g_currentScene = self;
    if (g_menuNeedsRefresh.exchange(false)) {
        closeMenu();
        openMenu();
    } else if (g_menuNeedsClose.exchange(false)) {
        closeMenu();
    }
    invokeTickCallbacks(dt);
    companionTick(dt);
    spawnedNpcsTick(dt);
}

bool installHooks() {
    if (!g_originalInit) {
        LOGE("GameScene::init symbol not found");
        return false;
    }
    void* initTrampoline = nullptr;
    const int initResult = DobbyHook(reinterpret_cast<void*>(g_originalInit), reinterpret_cast<void*>(hookedGameSceneInit), &initTrampoline);
    if (initResult != 0 || !initTrampoline) {
        LOGE("GameScene::init hook failed: %d", initResult);
        return false;
    }
    g_originalInit = reinterpret_cast<GameSceneInitFn>(initTrampoline);

    if (!g_originalFrameMove) {
        LOGW("GameScene::FrameMove symbol not found; menu works, tick scripts and companion AI are disabled");
        g_hooksInstalled.store(true);
        return true;
    }
    void* frameTrampoline = nullptr;
    const int frameResult = DobbyHook(reinterpret_cast<void*>(g_originalFrameMove), reinterpret_cast<void*>(hookedGameSceneFrameMove), &frameTrampoline);
    if (frameResult == 0 && frameTrampoline) {
        g_originalFrameMove = reinterpret_cast<GameSceneFrameMoveFn>(frameTrampoline);
    } else {
        LOGW("GameScene::FrameMove hook failed: %d; menu works, tick scripts and companion AI are disabled", frameResult);
        g_originalFrameMove = nullptr;
    }
    g_hooksInstalled.store(true);
    LOGI("NST hooks installed");
    return true;
}

std::string javaFilePath(JNIEnv* env, jobject file) {
    if (!file) return {};
    jclass fileClass = env->GetObjectClass(file);
    jmethodID getAbsolutePath = env->GetMethodID(fileClass, "getAbsolutePath", "()Ljava/lang/String;");
    jstring path = getAbsolutePath ? static_cast<jstring>(env->CallObjectMethod(file, getAbsolutePath)) : nullptr;
    std::string result;
    if (path) {
        const char* chars = env->GetStringUTFChars(path, nullptr);
        if (chars) { result = chars; env->ReleaseStringUTFChars(path, chars); }
        env->DeleteLocalRef(path);
    }
    env->DeleteLocalRef(fileClass);
    return result;
}

void initializeFromActivity(JNIEnv* env, jobject activity) {
    jclass activityClass = env->GetObjectClass(activity);
    std::string legacyFilesPath;
    jmethodID getExternalFilesDir = env->GetMethodID(activityClass, "getExternalFilesDir", "(Ljava/lang/String;)Ljava/io/File;");
    jobject oldFiles = getExternalFilesDir ? env->CallObjectMethod(activity, getExternalFilesDir, nullptr) : nullptr;
    if (env->ExceptionCheck()) env->ExceptionClear();
    legacyFilesPath = javaFilePath(env, oldFiles);
    if (oldFiles) env->DeleteLocalRef(oldFiles);

    std::string mediaRoot;
    jmethodID getExternalMediaDirs = env->GetMethodID(activityClass, "getExternalMediaDirs", "()[Ljava/io/File;");
    if (env->ExceptionCheck()) env->ExceptionClear();
    jobjectArray mediaDirs = getExternalMediaDirs ? static_cast<jobjectArray>(env->CallObjectMethod(activity, getExternalMediaDirs)) : nullptr;
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (mediaDirs && env->GetArrayLength(mediaDirs) > 0) {
        jobject mediaDir = env->GetObjectArrayElement(mediaDirs, 0);
        mediaRoot = javaFilePath(env, mediaDir);
        if (mediaDir) env->DeleteLocalRef(mediaDir);
    }
    if (mediaDirs) env->DeleteLocalRef(mediaDirs);
    env->DeleteLocalRef(activityClass);

    if (!mediaRoot.empty()) g_basePath = joinPath(mediaRoot, "NSTMods");
    else if (!legacyFilesPath.empty()) g_basePath = joinPath(legacyFilesPath, "NSTMods");
    else {
        jclass cls = env->GetObjectClass(activity);
        jmethodID getFilesDir = env->GetMethodID(cls, "getFilesDir", "()Ljava/io/File;");
        jobject files = getFilesDir ? env->CallObjectMethod(activity, getFilesDir) : nullptr;
        if (env->ExceptionCheck()) env->ExceptionClear();
        g_basePath = javaFilePath(env, files);
        if (files) env->DeleteLocalRef(files);
        env->DeleteLocalRef(cls);
    }
    if (g_basePath.empty()) {
        LOGE("Could not resolve NSTMods directory");
        return;
    }

    makeDirectories(g_basePath);
    makeDirectories(joinPath(g_basePath, "Scripts"));
    makeDirectories(joinPath(g_basePath, "Mods"));
    makeDirectories(joinPath(g_basePath, "texture_pack"));

    if (!legacyFilesPath.empty()) {
        const std::string oldData = joinPath(legacyFilesPath, "Data");
        copyDirectoryIfMissing(joinPath(oldData, "Scripts"), joinPath(g_basePath, "Scripts"));
        copyDirectoryIfMissing(joinPath(oldData, "Mods"), joinPath(g_basePath, "Mods"));
        copyDirectoryIfMissing(joinPath(oldData, "texture_pack"), joinPath(g_basePath, "texture_pack"));
    }

    jclass cls = env->GetObjectClass(activity);
    jmethodID getAssets = env->GetMethodID(cls, "getAssets", "()Landroid/content/res/AssetManager;");
    jobject javaAssets = getAssets ? env->CallObjectMethod(activity, getAssets) : nullptr;
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (javaAssets) {
        AAssetManager* assets = AAssetManager_fromJava(env, javaAssets);
        if (assets) copyAssetTree(assets, "nst", g_basePath);
        env->DeleteLocalRef(javaAssets);
    }
    env->DeleteLocalRef(cls);

    const std::string original = joinPath(g_basePath, "texture_pack/Original");
    const std::string active = joinPath(g_basePath, "texture_pack/Active");
    if (!isDirectory(active)) copyDirectoryIfMissing(original, active);
    LOGI("Mods directory: %s", g_basePath.c_str());
}
}

extern "C" JNIEXPORT void JNICALL
Java_com_nst_mod_NstModBootstrap_nativeInstall(JNIEnv* env, jclass, jobject activity) {
    if (g_initialized.exchange(true)) return;
    initializeFromActivity(env, activity);
    g_gameHandle = dlopen("libMyGame.so", RTLD_NOW | RTLD_NOLOAD);
    if (!g_gameHandle) g_gameHandle = dlopen("libMyGame.so", RTLD_NOW);
    if (!g_gameHandle) {
        LOGE("Cannot open libMyGame.so: %s", dlerror());
        return;
    }
    resolveGameSymbols();
    if (!installHooks()) LOGE("NST hooks could not be installed; original game is left untouched");
}
