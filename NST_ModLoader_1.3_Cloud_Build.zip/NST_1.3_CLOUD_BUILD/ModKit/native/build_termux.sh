#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
NDK="${ANDROID_NDK_HOME:-}"
if [ -z "$NDK" ] && [ -f "$HOME/.nst-ndk-path" ]; then
    NDK="$(cat "$HOME/.nst-ndk-path")"
fi
if [ -z "$NDK" ] || [ ! -f "$NDK/build/cmake/android.toolchain.cmake" ]; then
    echo 'NDK не найден. Сначала запусти termux/install_ndk.sh из комплекта.' >&2
    exit 2
fi
if [ "$(uname -m)" != 'aarch64' ]; then
    echo "Нужен ARM64 Termux, обнаружен: $(uname -m)" >&2
    exit 2
fi

BUILD="$ROOT/build/termux-arm64-v8a"
OUT="$ROOT/out/arm64-v8a"
mkdir -p "$OUT"

cmake -S "$ROOT" -B "$BUILD" -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_NDK="$NDK" \
  -DANDROID_ABI=arm64-v8a \
  -DANDROID_PLATFORM=android-21 \
  -DANDROID_STL=c++_static \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_SHARED_LINKER_FLAGS='-Wl,-z,max-page-size=16384'

cmake --build "$BUILD" --target nstmod --parallel 2
install -m 0644 "$BUILD/libnstmod.so" "$OUT/libnstmod.so"

READELF="$(command -v llvm-readelf || command -v readelf || true)"
if [ -n "$READELF" ]; then
    echo '\nЗависимости libnstmod.so:'
    "$READELF" -d "$OUT/libnstmod.so" | grep NEEDED || true
    echo '\nАрхитектура:'
    "$READELF" -h "$OUT/libnstmod.so" | grep -E 'Class:|Machine:' || true
fi
printf '\nСобрана библиотека: %s\n' "$OUT/libnstmod.so"
