#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
KIT="$ROOT/ModKit"
APK_DIR="$ROOT/APK"
DECODED="$APK_DIR/decoded_nors"
APKTOOL="$HOME/bin/apktool.jar"
KEYSTORE="$HOME/nst-mod.keystore"
OUT="$APK_DIR/NecromancerStory_MOD.apk"
UNSIGNED="$APK_DIR/NST_unsigned.apk"

[ -d "$DECODED" ] || { echo "Нет $DECODED. Нужна уже декодированная no-resources папка." >&2; exit 2; }
[ -f "$APKTOOL" ] || { echo "Нет $APKTOOL" >&2; exit 2; }
[ -f "$KEYSTORE" ] || { echo "Нет $KEYSTORE" >&2; exit 2; }

bash "$KIT/native/build_termux.sh"
mkdir -p "$DECODED/lib/arm64-v8a"
[ -f "$PREFIX/aarch64-linux-android/lib/libc++_shared.so" ] || { echo "Не найдена libc++_shared.so в Termux PREFIX" >&2; exit 2; }
cp "$PREFIX/aarch64-linux-android/lib/libc++_shared.so" "$DECODED/lib/arm64-v8a/libc++_shared.so"
python "$KIT/patch_apktool.py" "$DECODED" --kit "$KIT" --libs-dir "$KIT/native/out" --abis arm64-v8a
rm -f "$UNSIGNED" "$OUT"
java -jar "$APKTOOL" b "$DECODED" -o "$UNSIGNED"
apksigner sign --ks "$KEYSTORE" --ks-key-alias nst --out "$OUT" "$UNSIGNED"
apksigner verify --verbose "$OUT"

unzip -l "$OUT" | grep -q 'assets/nst/Scripts/NPCSpawner/main.js' || { echo "В APK нет скрипта NPCSpawner" >&2; exit 3; }
if unzip -l "$OUT" | grep -q 'assets/nst/Data/'; then
    echo "Ошибка: старая папка assets/nst/Data всё ещё попала в APK" >&2
    exit 3
fi

echo "Готово: $OUT"
termux-open "$OUT"
